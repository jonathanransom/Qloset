"""
Wardrobe System — standalone weather test.

Usage:
    python weather_test.py
"""

from app.weather import get_weather


def main():
    data, source = get_weather()
    print(f"Source: {source}")
    if data is None:
        print("No weather data available (no live fetch succeeded, and nothing cached yet).")
        return

    print(f"Temp: {data.temp}°F (feels like {data.feels_like}°F)")
    print(f"Condition: {data.condition}")
    print(f"High/Low: {data.high}/{data.low}°F")
    print(f"Rain probability: {data.rain_probability}%")
    print(f"Wind: {data.wind} mph, Humidity: {data.humidity}%")
    print(f"As of: {data.fetched_at.isoformat(timespec='seconds')}")


if __name__ == "__main__":
    main()
