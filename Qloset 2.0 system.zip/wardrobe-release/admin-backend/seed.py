"""
Wardrobe System — baseline seed data.

Run once after migrations to populate:
  - core clothing types (extensible list — add more rows any time)
  - the tag vocabulary from your Phase 1 examples
  - your stated default weekly schedule (fully editable later via the
    admin UI once Phase 3b exists — this is just a starting point so
    Phase 3a has real data to query against)

Safe to re-run: it checks for existing rows by slug/day before inserting.
"""

from db.database import get_session, init_db
from db.models import ClothingType, ScheduleRule, Tag

CLOTHING_TYPES = [
    # (name, slug, outfit_slot, sort_order)
    ("Shirt", "shirt", "top", 10),
    ("Polo Shirt", "polo", "top", 20),
    ("Pants", "pants", "bottom", 30),
    ("Shorts", "shorts", "bottom", 40),
]

TAGS = [
    # (name, slug, category)
    ("Work", "work", "occasion"),
    ("Casual", "casual", "occasion"),
    ("Church", "church", "occasion"),
    ("Formal", "formal", "occasion"),
    ("Business Casual", "business-casual", "occasion"),
    ("Saturday", "saturday", "day"),
    ("Holiday", "holiday", "day"),
    ("Vacation", "vacation", "day"),
    ("Hot Weather", "hot-weather", "weather"),
    ("Cold Weather", "cold-weather", "weather"),
    ("Rain", "rain", "weather"),
]

# day_of_week: 0=Monday .. 6=Sunday, per your stated default schedule
DEFAULT_SCHEDULE = [
    (0, "Monday", ["Work", "Formal"]),
    (1, "Tuesday", ["Work", "Formal"]),
    (2, "Wednesday", ["Work", "Formal"]),
    (3, "Thursday", ["Work", "Formal"]),
    (4, "Friday", ["Work", "Business Casual"]),
    (5, "Saturday", ["Casual"]),
    (6, "Sunday", ["Church"]),
]
# Note: I used "Formal" as the stand-in for "Business" from your Section 5
# example (business/business-casual clothing) since "Business" wasn't in
# your explicit tag list — rename/retag this in the admin UI (Phase 3b)
# if you'd rather have a dedicated "Business" tag.


def seed():
    init_db()  # in case migrations haven't been run yet in a fresh dev checkout

    with get_session() as session:
        type_by_slug = {}
        for name, slug, outfit_slot, sort_order in CLOTHING_TYPES:
            existing = session.query(ClothingType).filter_by(slug=slug).one_or_none()
            if existing:
                type_by_slug[slug] = existing
                continue
            ct = ClothingType(name=name, slug=slug, outfit_slot=outfit_slot, sort_order=sort_order)
            session.add(ct)
            type_by_slug[slug] = ct
        session.flush()

        tag_by_name = {}
        for name, slug, category in TAGS:
            existing = session.query(Tag).filter_by(slug=slug).one_or_none()
            if existing:
                tag_by_name[name] = existing
                continue
            tag = Tag(name=name, slug=slug, category=category)
            session.add(tag)
            tag_by_name[name] = tag
        session.flush()

        for day_of_week, label, tag_names in DEFAULT_SCHEDULE:
            existing = session.query(ScheduleRule).filter_by(day_of_week=day_of_week).one_or_none()
            if existing:
                continue
            rule = ScheduleRule(day_of_week=day_of_week, label=label)
            rule.tags = [tag_by_name[name] for name in tag_names]
            session.add(rule)

    print("Seed complete.")


if __name__ == "__main__":
    seed()
