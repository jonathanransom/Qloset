"""
Wardrobe System — wardrobe-wide statistics (Phase 8).

Everything here builds on the per-item helpers in app/stats.py — nothing
new is stored; these are all read-time aggregations over ClothingItem and
WearHistory, per the same "never store a derived value" rule from
Section 10. Kept in a separate module from stats.py (which is about one
item at a time) so wardrobe-wide queries don't get pulled into every
per-item response.
"""

from __future__ import annotations

from datetime import date, timedelta

from sqlalchemy import func
from sqlalchemy.orm import Session

from app import stats
from db.models import ClothingItem, WearHistory


def wears_by_day_type(session: Session, clothing_item_id: int) -> dict:
    """
    Section 9: wears on Sundays / weekdays / Saturdays, broken out
    separately — this is what lets the admin UI show "3 Sunday wears,
    12 weekday wears" for an item, distinct from its raw total.
    """
    dates = (
        session.query(WearHistory.worn_date)
        .filter(WearHistory.clothing_item_id == clothing_item_id)
        .all()
    )
    counts = {"sunday": 0, "saturday": 0, "weekday": 0}
    for (d,) in dates:
        weekday = d.weekday()  # Monday=0 .. Sunday=6
        if weekday == 6:
            counts["sunday"] += 1
        elif weekday == 5:
            counts["saturday"] += 1
        else:
            counts["weekday"] += 1
    return counts


def item_detail_stats(session: Session, item: ClothingItem) -> dict:
    """Full per-item breakdown for the item detail / stats view."""
    today = date.today()
    base = stats.stats_for_item(session, item)
    return {
        **base,
        "wears_last_7_days": stats.wears_since(session, item.id, today - timedelta(days=7)),
        "wears_last_30_days": stats.wears_since(session, item.id, today - timedelta(days=30)),
        **wears_by_day_type(session, item.id),
    }


def wardrobe_overview(session: Session) -> dict:
    """
    The dashboard/statistics-page summary: totals, extremes, and averages
    across the whole wardrobe. All computed at read time from
    clothing_items + wear_history — nothing here is a stored column.
    """
    items = session.query(ClothingItem).all()
    if not items:
        return {
            "total_items": 0,
            "total_wardrobe_value": 0.0,
            "average_wears_per_item": 0.0,
            "most_worn": None,
            "least_worn": None,
            "highest_cost_per_wear": None,
            "lowest_cost_per_wear": None,
        }

    per_item = []
    for item in items:
        wears = stats.total_wears(session, item.id)
        per_item.append(
            {
                "id": item.id,
                "name": item.name,
                "wears": wears,
                "cost_per_wear": stats.cost_per_wear(item, wears),
                "purchase_price": item.purchase_price,
            }
        )

    total_value = sum(i["purchase_price"] or 0 for i in per_item)
    total_wears_all = sum(i["wears"] for i in per_item)

    most_worn = max(per_item, key=lambda i: i["wears"], default=None)
    least_worn = min(per_item, key=lambda i: i["wears"], default=None)

    priced = [i for i in per_item if i["cost_per_wear"] is not None]
    highest_cpw = max(priced, key=lambda i: i["cost_per_wear"], default=None)
    lowest_cpw = min(priced, key=lambda i: i["cost_per_wear"], default=None)

    return {
        "total_items": len(items),
        "total_wardrobe_value": round(total_value, 2),
        "average_wears_per_item": round(total_wears_all / len(items), 2),
        "most_worn": most_worn,
        "least_worn": least_worn,
        "highest_cost_per_wear": highest_cpw,
        "lowest_cost_per_wear": lowest_cpw,
    }


def wears_over_time(session: Session, days: int = 90) -> list[dict]:
    """
    Daily wear counts for the last `days` days — feeds the "wear activity
    over time" chart. Days with zero wears are included as 0, not
    omitted, so the chart doesn't silently skip gaps.
    """
    start = date.today() - timedelta(days=days - 1)
    rows = (
        session.query(WearHistory.worn_date, func.count(WearHistory.id))
        .filter(WearHistory.worn_date >= start)
        .group_by(WearHistory.worn_date)
        .all()
    )
    counts = {d: c for d, c in rows}
    return [
        {"date": (start + timedelta(days=i)).isoformat(), "wears": counts.get(start + timedelta(days=i), 0)}
        for i in range(days)
    ]


def needs_attention(session: Session, unworn_days_threshold: int = 90) -> list[dict]:
    """
    Section 21's "I haven't worn this in 90 days" idea, in its simplest
    useful form: active items unworn for longer than the threshold (or
    never worn at all). Not a notification system yet — just a list the
    dashboard can surface, per the "start simple" instruction.
    """
    results = []
    for item in session.query(ClothingItem).filter_by(status="active").all():
        days_unworn = stats.days_since_worn(session, item.id)
        if days_unworn is None or days_unworn >= unworn_days_threshold:
            results.append({"id": item.id, "name": item.name, "days_since_worn": days_unworn})
    # Never-worn items (days_since_worn is None) sort to the top, as the
    # most neglected of all — a plain reverse-sort on the raw value would
    # instead push them to the bottom since None can't compare to an int.
    return sorted(results, key=lambda r: r["days_since_worn"] if r["days_since_worn"] is not None else float("inf"), reverse=True)
