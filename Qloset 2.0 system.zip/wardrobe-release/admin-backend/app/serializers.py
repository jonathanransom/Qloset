"""
Wardrobe System — shared ORM -> Pydantic conversion for clothing items.

Factored out of app/routers/clothing.py so any other router (the new QR
scan endpoint, and later the recommendation engine's API) can produce the
exact same ClothingItemOut shape without duplicating the getattr()-based
column reading or the stats lookup.
"""

from app import stats
from app.schemas import ClothingItemOut
from db.models import ClothingItem


def clothing_item_to_out(session, item: ClothingItem) -> ClothingItemOut:
    s = stats.stats_for_item(session, item)
    # Read every column via getattr() rather than item.__dict__ — __dict__
    # only contains attributes that were explicitly set, so a freshly
    # created item (e.g. photo_path, only ever set later via the photo
    # upload endpoint) would simply be missing from it instead of being
    # None. getattr() goes through SQLAlchemy's normal attribute access
    # instead, which always returns the real value.
    column_data = {col.name: getattr(item, col.name) for col in ClothingItem.__table__.columns}
    column_data["status"] = item.status.value if hasattr(item.status, "value") else item.status
    return ClothingItemOut.model_validate(
        {
            **column_data,
            "tags": item.tags,
            **s,
        }
    )
