"""
Wardrobe System — weather retrieval & caching.

Per Phase 1 and Section 23:
  - the weather PROVIDER is swappable — everything outside this module
    only ever sees WeatherData / get_weather(), never Open-Meteo specifics,
    so switching providers later means changing this one file
  - if the API/network is unavailable, we fall back to the most recent
    cached reading rather than failing outright; if there's no cache at
    all, we return None and say so — callers (the API, later the
    recommendation engine) must handle "no weather data" without crashing
  - nothing here is a stored, authoritative "current condition" — every
    successful fetch is logged as a new weather_history row, which is
    also what Phase 8's history/statistics views will read from later
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from datetime import datetime, timedelta

import requests
from sqlalchemy import func

from db.database import get_session
from db.models import WeatherHistory

log = logging.getLogger("wardrobe.weather")

# Configuration — no hard-coded location. Set these to your actual
# coordinates (e.g. via a lookup like latlong.net).
LATITUDE = os.environ.get("WARDROBE_LATITUDE")
LONGITUDE = os.environ.get("WARDROBE_LONGITUDE")
CACHE_MINUTES = float(os.environ.get("WARDROBE_WEATHER_CACHE_MINUTES", "30"))
REQUEST_TIMEOUT_SECONDS = 10

OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"

# WMO weather interpretation codes, as used by Open-Meteo's `weather_code`.
# Collapsed to the handful of categories that matter for outfit decisions —
# exact phrasing doesn't need to be exhaustive for v1.
WEATHER_CODE_DESCRIPTIONS = {
    0: "Clear",
    1: "Mostly clear",
    2: "Partly cloudy",
    3: "Overcast",
    45: "Fog",
    48: "Fog",
    51: "Light drizzle",
    53: "Drizzle",
    55: "Heavy drizzle",
    56: "Freezing drizzle",
    57: "Freezing drizzle",
    61: "Light rain",
    63: "Rain",
    65: "Heavy rain",
    66: "Freezing rain",
    67: "Freezing rain",
    71: "Light snow",
    73: "Snow",
    75: "Heavy snow",
    77: "Snow grains",
    80: "Light showers",
    81: "Showers",
    82: "Violent showers",
    85: "Snow showers",
    86: "Snow showers",
    95: "Thunderstorm",
    96: "Thunderstorm with hail",
    99: "Thunderstorm with hail",
}


class WeatherUnavailableError(Exception):
    """Raised internally when the provider can't be reached — callers should catch this."""


@dataclass
class WeatherData:
    temp: float | None
    feels_like: float | None
    condition: str | None
    rain_probability: float | None
    precipitation: float | None
    wind: float | None
    humidity: float | None
    high: float | None
    low: float | None
    fetched_at: datetime
    raw_json: str | None = None


def _fetch_from_open_meteo() -> WeatherData:
    if not LATITUDE or not LONGITUDE:
        raise WeatherUnavailableError(
            "WARDROBE_LATITUDE / WARDROBE_LONGITUDE are not set — can't fetch weather."
        )

    params = {
        "latitude": LATITUDE,
        "longitude": LONGITUDE,
        "current": "temperature_2m,apparent_temperature,relative_humidity_2m,"
        "precipitation,weather_code,wind_speed_10m",
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
        "temperature_unit": "fahrenheit",
        "wind_speed_unit": "mph",
        "timezone": "auto",
        "forecast_days": 1,
    }

    try:
        response = requests.get(params=params, url=OPEN_METEO_URL, timeout=REQUEST_TIMEOUT_SECONDS)
        response.raise_for_status()
        payload = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise WeatherUnavailableError(f"Open-Meteo request failed: {exc}") from exc

    current = payload.get("current", {})
    daily = payload.get("daily", {})

    weather_code = current.get("weather_code")
    condition = WEATHER_CODE_DESCRIPTIONS.get(weather_code, f"Code {weather_code}" if weather_code is not None else None)

    def first(values):
        return values[0] if values else None

    return WeatherData(
        temp=current.get("temperature_2m"),
        feels_like=current.get("apparent_temperature"),
        condition=condition,
        rain_probability=first(daily.get("precipitation_probability_max", [])),
        precipitation=current.get("precipitation"),
        wind=current.get("wind_speed_10m"),
        humidity=current.get("relative_humidity_2m"),
        high=first(daily.get("temperature_2m_max", [])),
        low=first(daily.get("temperature_2m_min", [])),
        fetched_at=datetime.utcnow(),
        raw_json=response.text,
    )


def _latest_cached(session) -> WeatherHistory | None:
    return session.query(WeatherHistory).order_by(WeatherHistory.fetched_at.desc()).first()


def get_weather() -> tuple[WeatherData | None, str]:
    """
    Returns (weather, source) where source is one of:
      "live"        — freshly fetched just now
      "cached"      — reused a recent cache entry (within CACHE_MINUTES), no request made
      "stale_cache" — the live fetch failed, fell back to an older cached reading
      "unavailable" — the live fetch failed AND there's no cache at all

    Callers must handle weather being None (the "unavailable" case) —
    per Section 23, the rest of the system (especially the recommendation
    engine in Phase 6) should degrade to weather-independent logic rather
    than fail outright.
    """
    with get_session() as session:
        cached = _latest_cached(session)
        if cached and cached.fetched_at > datetime.utcnow() - timedelta(minutes=CACHE_MINUTES):
            return _row_to_data(cached), "cached"

        try:
            fresh = _fetch_from_open_meteo()
        except WeatherUnavailableError as exc:
            log.warning("Weather fetch failed, falling back to cache if available: %s", exc)
            if cached:
                return _row_to_data(cached), "stale_cache"
            return None, "unavailable"

        row = WeatherHistory(
            fetched_at=fresh.fetched_at,
            temp=fresh.temp,
            feels_like=fresh.feels_like,
            condition=fresh.condition,
            rain_probability=fresh.rain_probability,
            precipitation=fresh.precipitation,
            wind=fresh.wind,
            humidity=fresh.humidity,
            high=fresh.high,
            low=fresh.low,
            raw_json=fresh.raw_json,
        )
        session.add(row)
        return fresh, "live"


def _row_to_data(row: WeatherHistory) -> WeatherData:
    return WeatherData(
        temp=row.temp,
        feels_like=row.feels_like,
        condition=row.condition,
        rain_probability=row.rain_probability,
        precipitation=row.precipitation,
        wind=row.wind,
        humidity=row.humidity,
        high=row.high,
        low=row.low,
        fetched_at=row.fetched_at,
        raw_json=None,  # not needed once round-tripped through the API/UI
    )
