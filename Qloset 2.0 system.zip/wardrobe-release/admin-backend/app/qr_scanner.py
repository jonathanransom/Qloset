"""
Wardrobe System — QR code scanning.

Per the Phase 1 requirement, the camera is NOT running continuously — it's
opened only when a scan is requested, held open for at most
`timeout_seconds` (or until a code is found, whichever comes first), then
released immediately. That keeps the camera free for other uses and avoids
pointlessly burning CPU/power watching an idle feed.

This module has no FastAPI/web dependency — it's plain camera + decoding
logic, so it can be exercised standalone (see scan_test.py) or from the
API (app/routers/scan.py), and later from the physical button workflow in
Phase 7, without duplication.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass
from enum import Enum

import cv2
from pyzbar import pyzbar

log = logging.getLogger("wardrobe.qr_scanner")

CAMERA_INDEX = int(os.environ.get("WARDROBE_CAMERA_INDEX", "0"))
DEFAULT_TIMEOUT_SECONDS = float(os.environ.get("WARDROBE_SCAN_TIMEOUT_SECONDS", "10"))
PREVIEW_JPEG_QUALITY = int(os.environ.get("WARDROBE_PREVIEW_JPEG_QUALITY", "70"))

# Shared state for the live preview (app/routers/scan.py's GET
# /api/scan/preview.mjpg). The camera can only be held open by one
# consumer at a time, and scan_once() below already owns it for the
# duration of a scan attempt — so the preview does NOT open a second
# camera handle. It just reads whatever frame scan_once() most recently
# grabbed, cached here behind a lock. _scan_active tells the preview
# endpoint whether a scan is currently running at all.
_frame_lock = threading.Lock()
_scan_active = threading.Event()
_latest_frame_jpeg: bytes | None = None


class ScanStatus(str, Enum):
    detected = "detected"
    timeout = "timeout"
    camera_unavailable = "camera_unavailable"


@dataclass
class ScanResult:
    status: ScanStatus
    qr_code: str | None = None


def scan_once(timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS) -> ScanResult:
    """
    Opens the camera, watches frames for a decodable QR code for up to
    `timeout_seconds`, then closes the camera no matter what happened.
    Returns a ScanResult — never raises for "normal" outcomes (no camera,
    nothing found), since those are expected conditions the caller (API
    endpoint, button workflow) needs to handle gracefully, not exceptions.
    """
    capture = cv2.VideoCapture(CAMERA_INDEX)
    if not capture.isOpened():
        log.warning("Camera at index %s could not be opened", CAMERA_INDEX)
        capture.release()
        return ScanResult(status=ScanStatus.camera_unavailable)

    _scan_active.set()
    try:
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            ok, frame = capture.read()
            if not ok:
                # A transient frame-grab failure isn't the same as the
                # camera being unavailable — keep trying until the deadline.
                continue

            _cache_preview_frame(frame)

            codes = pyzbar.decode(frame)
            if codes:
                value = codes[0].data.decode("utf-8", errors="replace")
                log.info("Decoded QR code: %s", value)
                return ScanResult(status=ScanStatus.detected, qr_code=value)

        log.info("No QR code detected within %.1fs", timeout_seconds)
        return ScanResult(status=ScanStatus.timeout)
    finally:
        capture.release()
        _scan_active.clear()
        with _frame_lock:
            global _latest_frame_jpeg
            _latest_frame_jpeg = None


def _cache_preview_frame(frame) -> None:
    global _latest_frame_jpeg
    ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), PREVIEW_JPEG_QUALITY])
    if ok:
        with _frame_lock:
            _latest_frame_jpeg = buf.tobytes()


def is_scanning() -> bool:
    return _scan_active.is_set()


def mjpeg_preview_frames(startup_grace_seconds: float = 3.0):
    """
    Generator of multipart/x-mixed-replace JPEG chunks for as long as a
    scan is actually in progress — i.e. only while some call to
    scan_once() is running and feeding _latest_frame_jpeg above. If no
    scan starts within `startup_grace_seconds` (covers the brief race
    where the kiosk's preview request lands a beat before its own POST
    /api/scan does), the generator just ends rather than hanging open.
    Ends on its own as soon as the active scan finishes, so the stream
    naturally closes when there's nothing left to show.
    """
    start = time.monotonic()
    while not is_scanning():
        if time.monotonic() - start > startup_grace_seconds:
            return
        time.sleep(0.05)

    boundary = b"--frame"
    last_sent = None
    while is_scanning():
        with _frame_lock:
            frame = _latest_frame_jpeg
        if frame is not None and frame is not last_sent:
            last_sent = frame
            yield (
                boundary + b"\r\n"
                b"Content-Type: image/jpeg\r\n"
                b"Content-Length: " + str(len(frame)).encode() + b"\r\n\r\n"
                + frame + b"\r\n"
            )
        time.sleep(0.1)  # ~10fps cap - plenty for "am I in frame", easy on the board's CPU
