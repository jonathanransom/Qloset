"""
Wardrobe System — derived statistics helpers.

Per the Phase 1 requirement, none of these are stored columns — they're
always computed from purchase_price and WearHistory rows, so there's a
single source of truth and no risk of the stored value drifting from
reality.

These are used by the admin API now, and will be reused unchanged by the
recommendation engine (Phase 6) and the statistics dashboard (Phase 8) —
this module has no FastAPI or web dependency, just the DB session, so it
stays usable from anywhere.
"""

from datetime import date

from sqlalchemy import func
from sqlalchemy.orm import Session

from db.models import ClothingItem, WearHistory


def total_wears(session: Session, clothing_item_id: int) -> int:
    return (
        session.query(func.count(WearHistory.id))
        .filter(WearHistory.clothing_item_id == clothing_item_id)
        .scalar()
        or 0
    )


def wears_since(session: Session, clothing_item_id: int, since: date) -> int:
    return (
        session.query(func.count(WearHistory.id))
        .filter(WearHistory.clothing_item_id == clothing_item_id, WearHistory.worn_date >= since)
        .scalar()
        or 0
    )


def weeks_since_last_worn_on_weekday(session: Session, clothing_item_id: int, weekday: int) -> int | None:
    """
    weekday: Python convention, Monday=0 .. Sunday=6.
    Used for the Sunday/church rotation specifically (Section 8) — this is
    a different question from "days since last worn at all", since an item
    worn on a Tuesday shouldn't count as recently worn "to church".
    Returns None if it's never been worn on that weekday.
    """
    all_dates = (
        session.query(WearHistory.worn_date)
        .filter(WearHistory.clothing_item_id == clothing_item_id)
        .all()
    )
    matching = [d for (d,) in all_dates if d.weekday() == weekday]
    if not matching:
        return None
    most_recent = max(matching)
    return (date.today() - most_recent).days // 7


def last_worn_date(session: Session, clothing_item_id: int) -> date | None:
    result = (
        session.query(func.max(WearHistory.worn_date))
        .filter(WearHistory.clothing_item_id == clothing_item_id)
        .scalar()
    )
    return result


def days_since_worn(session: Session, clothing_item_id: int) -> int | None:
    last = last_worn_date(session, clothing_item_id)
    if last is None:
        return None
    return (date.today() - last).days


def cost_per_wear(item: ClothingItem, wears: int) -> float | None:
    if not item.purchase_price or wears <= 0:
        return None
    return round(item.purchase_price / wears, 2)


def stats_for_item(session: Session, item: ClothingItem) -> dict:
    """Bundle of everything the API/UI needs for one clothing item."""
    wears = total_wears(session, item.id)
    return {
        "total_wears": wears,
        "cost_per_wear": cost_per_wear(item, wears),
        "last_worn_date": last_worn_date(session, item.id),
        "days_since_worn": days_since_worn(session, item.id),
    }
