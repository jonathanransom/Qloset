"""
Wardrobe System — QR code generation (Section 15 admin feature).

Generates a QR code image encoding a clothing item's exact `qr_code`
value (e.g. "SHIRT-0007") — this is the label you print and physically
attach to the item, and is what the camera (Phase 4/7) decodes back to
look the item up.

Two outputs:
  - a single PNG for one item ("Download QR" on its edit page)
  - a printable PDF sheet of several QR codes laid out in a grid, each
    labeled with the item's name and QR code text underneath, so a page
    of labels can be printed and cut apart at once
"""

from __future__ import annotations

import io

import qrcode
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas as pdf_canvas

# Layout for the printable sheet: a grid of labels, each a QR code with
# its name and code printed underneath. Tuned for a standard 8.5x11" page
# with reasonable margins — adjust these if you're using a different
# label sheet size.
LABEL_WIDTH = 2.2 * inch
LABEL_HEIGHT = 2.6 * inch
MARGIN = 0.4 * inch
COLS = 3


def generate_qr_png(data: str) -> bytes:
    """Returns PNG bytes for a single QR code encoding `data`."""
    img = qrcode.make(data, border=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def generate_label_sheet_pdf(items: list[dict]) -> bytes:
    """
    items: list of {"qr_code": str, "name": str}
    Returns a PDF (as bytes) with one label per item, arranged in a grid,
    each label showing the QR code, the item's name, and its QR code text.
    """
    buf = io.BytesIO()
    page_width, page_height = letter
    c = pdf_canvas.Canvas(buf, pagesize=letter)

    usable_width = page_width - 2 * MARGIN
    col_width = usable_width / COLS

    x, y = MARGIN, page_height - MARGIN - LABEL_HEIGHT

    for item in items:
        qr_img = qrcode.make(item["qr_code"], border=1)
        qr_buf = io.BytesIO()
        qr_img.save(qr_buf, format="PNG")
        qr_buf.seek(0)

        qr_size = min(LABEL_WIDTH, LABEL_HEIGHT) * 0.7
        qr_x = x + (LABEL_WIDTH - qr_size) / 2
        qr_y = y + LABEL_HEIGHT - qr_size - 10

        from reportlab.lib.utils import ImageReader

        c.drawImage(ImageReader(qr_buf), qr_x, qr_y, width=qr_size, height=qr_size)

        c.setFont("Helvetica-Bold", 9)
        c.drawCentredString(x + LABEL_WIDTH / 2, y + LABEL_HEIGHT - qr_size - 22, item["name"][:28])
        c.setFont("Helvetica", 8)
        c.drawCentredString(x + LABEL_WIDTH / 2, y + LABEL_HEIGHT - qr_size - 34, item["qr_code"])

        x += col_width
        if x + LABEL_WIDTH > page_width - MARGIN:
            x = MARGIN
            y -= LABEL_HEIGHT + 10
            if y < MARGIN:
                c.showPage()
                x, y = MARGIN, page_height - MARGIN - LABEL_HEIGHT

    c.save()
    return buf.getvalue()
