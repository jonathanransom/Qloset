"""
Wardrobe System — API schemas (Pydantic).

Kept separate from db/models.py deliberately: the ORM models describe how
data is stored, these describe what the API accepts/returns. That
separation is what lets the DB layer change independently of the web
layer (per the "keep the database layer independent from the GUI"
coding standard).
"""

from datetime import date, datetime

from pydantic import BaseModel, Field


# --- Tags -------------------------------------------------------------

class TagIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    category: str | None = None


class TagOut(BaseModel):
    id: int
    name: str
    slug: str
    category: str | None

    class Config:
        from_attributes = True


# --- Clothing types (read-only via this API for now; seeded directly) --

class ClothingTypeOut(BaseModel):
    id: int
    name: str
    slug: str
    outfit_slot: str

    class Config:
        from_attributes = True


# --- Clothing items -----------------------------------------------------

class ClothingItemIn(BaseModel):
    qr_code: str = Field(min_length=1, max_length=100)
    clothing_type_id: int
    name: str = Field(min_length=1, max_length=200)
    brand: str | None = None
    size: str | None = None
    color: str | None = None
    pattern: str | None = None
    material: str | None = None
    purchase_date: date | None = None
    purchase_price: float | None = Field(default=None, ge=0)
    status: str = "active"
    min_temp_f: float | None = None
    max_temp_f: float | None = None
    rain_ok: bool | None = None
    preference_boost: float = 0.0
    notes: str | None = None
    tag_ids: list[int] = []


class ClothingItemUpdate(BaseModel):
    # All optional — PUT applies only the fields provided.
    qr_code: str | None = None
    clothing_type_id: int | None = None
    name: str | None = None
    brand: str | None = None
    size: str | None = None
    color: str | None = None
    pattern: str | None = None
    material: str | None = None
    purchase_date: date | None = None
    purchase_price: float | None = Field(default=None, ge=0)
    status: str | None = None
    min_temp_f: float | None = None
    max_temp_f: float | None = None
    rain_ok: bool | None = None
    preference_boost: float | None = None
    notes: str | None = None
    tag_ids: list[int] | None = None


class ClothingItemOut(BaseModel):
    id: int
    qr_code: str
    clothing_type_id: int
    name: str
    brand: str | None
    size: str | None
    color: str | None
    pattern: str | None
    material: str | None
    purchase_date: date | None
    purchase_price: float | None
    status: str
    photo_path: str | None
    min_temp_f: float | None
    max_temp_f: float | None
    rain_ok: bool | None
    preference_boost: float
    notes: str | None
    created_at: datetime
    updated_at: datetime
    tags: list[TagOut]

    # Derived, computed at request time — see app/stats.py
    total_wears: int
    cost_per_wear: float | None
    last_worn_date: date | None
    days_since_worn: int | None

    class Config:
        from_attributes = True


# --- Wear history (manual logging for testing, ahead of Phase 4/7) -----

class WearIn(BaseModel):
    clothing_item_id: int
    worn_date: date | None = None  # defaults to today if omitted


class WearOut(BaseModel):
    id: int
    clothing_item_id: int
    worn_date: date
    source: str
    created_at: datetime

    class Config:
        from_attributes = True
