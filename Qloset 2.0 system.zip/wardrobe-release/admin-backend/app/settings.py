"""
Wardrobe System — settings access.

Backed by the `settings` key/value table so these can eventually be
changed from the web GUI (per Section 19) without a code change or
migration. Every setting has a hard-coded DEFAULT here, so a fresh
database with no settings rows yet still produces sensible behavior —
seed.py doesn't need to pre-populate every one.
"""

from db.models import Setting

DEFAULTS: dict[str, float] = {
    # Recommendation engine weights — see app/recommendation.py for how
    # each is used. All are roughly "points on a 0-10ish scale"; the
    # engine's comments explain what raising/lowering each one does.
    "weight_rotation": 10.0,
    "weight_weather": 8.0,
    "weight_sunday": 12.0,
    "weight_preference": 1.0,
    "weight_recent_penalty": 15.0,
    "weight_overuse_penalty": 5.0,
    # Behavior tuning, not weights:
    "recent_wear_days": 5,       # wearing something within this many days is "too soon"
    "rotation_cap_days": 30,     # rotation credit stops increasing past this many days unworn
    "sunday_rotation_cap_weeks": 26,
    "overuse_wears_cap": 10,     # wears-in-30-days above this is treated the same (diminishing)
    "tie_margin": 1.0,           # scores within this many points of the top are "tied" -> random pick
}


def get_setting(session, key: str) -> float:
    row = session.get(Setting, key)
    if row is None:
        if key not in DEFAULTS:
            raise KeyError(f"Unknown setting '{key}' and no default registered")
        return DEFAULTS[key]
    try:
        return float(row.value)
    except ValueError:
        return DEFAULTS.get(key, 0.0)


def get_all_settings(session) -> dict[str, float]:
    stored = {row.key: row for row in session.query(Setting).all()}
    return {key: get_setting(session, key) if key in stored else default for key, default in DEFAULTS.items()}


def set_setting(session, key: str, value: float) -> None:
    if key not in DEFAULTS:
        raise KeyError(f"Unknown setting '{key}'")
    row = session.get(Setting, key)
    if row:
        row.value = str(value)
    else:
        session.add(Setting(key=key, value=str(value)))
