"""
Wardrobe System — recommendation API.

`GET /api/recommendation/today` is what the Phase 7 kiosk UI calls each
morning. `?debug=true` includes the full per-candidate scoring breakdown —
the "show your work" view for tuning weights, also used by recommend_test.py.

`POST /api/recommendation/today/confirm` is the "WEAR THIS" button's
action: it copies today's OutfitItems into wear_history with
source=recommended_confirmed. This is the ONLY place a recommendation
turns into a recorded wear — nothing writes to wear_history just because
a recommendation was generated (Section 20). The scan-based "CHANGE"
workflow (app/routers/scan.py's existing endpoint, called per scanned
item) is the other, separate path into wear_history, with
source=manual_scan.
"""

from datetime import date

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.recommendation import generate_recommendation
from app.serializers import clothing_item_to_out
from app.schemas import ClothingItemOut
from db.database import get_session
from db.models import WearHistory, WearSource

router = APIRouter(prefix="/api/recommendation", tags=["recommendation"])


class RecommendationResponse(BaseModel):
    date: str
    items: dict[str, ClothingItemOut]
    already_confirmed: bool
    debug: dict | None = None


class ConfirmResponse(BaseModel):
    date: str
    wear_ids: list[int]


@router.get("/today", response_model=RecommendationResponse)
def get_today(debug: bool = False, force: bool = False):
    with get_session() as session:
        outfit, debug_info = generate_recommendation(session, target_date=date.today(), force=force)
        if outfit is None:
            raise HTTPException(
                422,
                detail={
                    "message": "No valid outfit could be generated for today.",
                    "debug": debug_info,
                },
            )
        items = {oi.slot: clothing_item_to_out(session, oi.clothing_item) for oi in outfit.items}

        # Let the kiosk UI know whether today's outfit was already
        # confirmed as worn — e.g. after a motion-triggered screen wake
        # re-displays the same recommendation, the "WEAR THIS" button
        # shouldn't invite a duplicate wear record.
        already_confirmed = (
            session.query(WearHistory)
            .filter_by(outfit_id=outfit.id, source=WearSource.recommended_confirmed)
            .first()
            is not None
        )

        return RecommendationResponse(
            date=outfit.date.isoformat(),
            items=items,
            already_confirmed=already_confirmed,
            debug=debug_info if debug else None,
        )


@router.post("/today/confirm", response_model=ConfirmResponse, status_code=201)
def confirm_today():
    """
    The "WEAR THIS" button. Records every item in today's recommended
    outfit as actually worn (source=recommended_confirmed). Safe to call
    more than once in a day — it won't create duplicate wear rows for
    items already confirmed today.
    """
    today = date.today()
    with get_session() as session:
        outfit, _ = generate_recommendation(session, target_date=today)  # reuses existing, doesn't regenerate
        if outfit is None:
            raise HTTPException(422, "No recommendation exists for today to confirm.")

        already_confirmed_ids = {
            row.clothing_item_id
            for row in session.query(WearHistory).filter_by(outfit_id=outfit.id).all()
        }

        wear_ids = []
        for outfit_item in outfit.items:
            if outfit_item.clothing_item_id in already_confirmed_ids:
                continue
            wear = WearHistory(
                clothing_item_id=outfit_item.clothing_item_id,
                worn_date=today,
                outfit_id=outfit.id,
                source=WearSource.recommended_confirmed,
            )
            session.add(wear)
            session.flush()
            wear_ids.append(wear.id)

        return ConfirmResponse(date=today.isoformat(), wear_ids=wear_ids)
