"""
Wardrobe System — tag CRUD.

Deleting a tag explicitly cleans up its rows in every join table
(clothing_tags, schedule_rule_tags, special_event_tags) first. SQLite
doesn't enforce foreign keys by default, so skipping this would leave
orphaned rows behind rather than raising an error — silently wrong data
is worse than a loud failure, so we clean up rather than rely on FK
enforcement being on.
"""

import re

from fastapi import APIRouter, HTTPException
from sqlalchemy import delete

from app.schemas import TagIn, TagOut
from db.database import get_session
from db.models import Tag, clothing_tags, schedule_rule_tags, special_event_tags

router = APIRouter(prefix="/api/tags", tags=["tags"])


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.strip().lower()).strip("-")
    if not slug:
        raise HTTPException(400, "Tag name must contain at least one letter or number")
    return slug


@router.get("", response_model=list[TagOut])
def list_tags():
    with get_session() as session:
        tags = session.query(Tag).order_by(Tag.category, Tag.name).all()
        # Convert while the session is still open — see the note in
        # clothing.py's list_clothing_types for why this matters.
        return [TagOut.model_validate(t) for t in tags]


@router.post("", response_model=TagOut, status_code=201)
def create_tag(payload: TagIn):
    slug = _slugify(payload.name)
    with get_session() as session:
        if session.query(Tag).filter_by(slug=slug).first():
            raise HTTPException(409, f"A tag named '{payload.name}' already exists")
        tag = Tag(name=payload.name.strip(), slug=slug, category=payload.category)
        session.add(tag)
        session.flush()
        return TagOut.model_validate(tag)


@router.put("/{tag_id}", response_model=TagOut)
def update_tag(tag_id: int, payload: TagIn):
    slug = _slugify(payload.name)
    with get_session() as session:
        tag = session.get(Tag, tag_id)
        if not tag:
            raise HTTPException(404, "Tag not found")
        conflict = session.query(Tag).filter(Tag.slug == slug, Tag.id != tag_id).first()
        if conflict:
            raise HTTPException(409, f"A tag named '{payload.name}' already exists")
        tag.name = payload.name.strip()
        tag.slug = slug
        tag.category = payload.category
        session.flush()
        return TagOut.model_validate(tag)


@router.delete("/{tag_id}", status_code=204)
def delete_tag(tag_id: int):
    with get_session() as session:
        tag = session.get(Tag, tag_id)
        if not tag:
            raise HTTPException(404, "Tag not found")

        for table in (clothing_tags, schedule_rule_tags, special_event_tags):
            session.execute(delete(table).where(table.c.tag_id == tag_id))

        session.delete(tag)
