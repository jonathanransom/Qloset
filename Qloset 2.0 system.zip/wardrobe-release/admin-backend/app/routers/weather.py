"""
Wardrobe System — weather endpoint.
"""

from fastapi import APIRouter
from pydantic import BaseModel

from app.weather import get_weather

router = APIRouter(prefix="/api/weather", tags=["weather"])


class WeatherResponse(BaseModel):
    source: str  # "live" | "cached" | "stale_cache" | "unavailable"
    temp: float | None = None
    feels_like: float | None = None
    condition: str | None = None
    rain_probability: float | None = None
    precipitation: float | None = None
    wind: float | None = None
    humidity: float | None = None
    high: float | None = None
    low: float | None = None
    fetched_at: str | None = None


@router.get("/current", response_model=WeatherResponse)
def current_weather():
    data, source = get_weather()
    if data is None:
        return WeatherResponse(source=source)
    return WeatherResponse(
        source=source,
        temp=data.temp,
        feels_like=data.feels_like,
        condition=data.condition,
        rain_probability=data.rain_probability,
        precipitation=data.precipitation,
        wind=data.wind,
        humidity=data.humidity,
        high=data.high,
        low=data.low,
        fetched_at=data.fetched_at.isoformat(timespec="seconds"),
    )
