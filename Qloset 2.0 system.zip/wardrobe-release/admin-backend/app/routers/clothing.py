"""
Wardrobe System — clothing CRUD, photo upload, and manual wear logging.

Photo handling deliberately does NOT trust the client's filename or
content-type header (both are attacker-controlled). Instead:
  - the file is opened with Pillow, which will refuse anything that
    isn't a real, decodable image
  - it's re-encoded to JPEG at a bounded max size, discarding any
    embedded metadata/scripts in the process
  - it's saved under a name WE choose (`<clothing_item_id>.jpg`), never
    anything derived from the uploaded filename
This satisfies the "sanitize uploaded images / avoid arbitrary file
upload vulnerabilities" requirement from the coding standards.
"""

import io
import logging
from datetime import date
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import Response
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel

from app import qr_generator
from app.serializers import clothing_item_to_out
from app.schemas import (
    ClothingItemIn,
    ClothingItemOut,
    ClothingItemUpdate,
    ClothingTypeOut,
    WearIn,
    WearOut,
)
from db.database import get_session
from db.models import ClothingItem, ClothingType, OutfitItem, Tag, WearHistory, WearSource

log = logging.getLogger("wardrobe.clothing")
router = APIRouter(prefix="/api/clothing", tags=["clothing"])

PHOTO_DIR = Path("data/photos")
PHOTO_DIR.mkdir(parents=True, exist_ok=True)
MAX_PHOTO_DIMENSION = 1600  # px, longest side — keeps files small for the on-device display
MAX_UPLOAD_BYTES = 8 * 1024 * 1024  # 8 MB, checked before we even try to decode it


@router.get("/types/list", response_model=list[ClothingTypeOut])
def list_clothing_types():
    """
    Registered clothing categories (Shirt, Polo Shirt, Pants, Shorts, ...).
    Lives here rather than as a full CRUD resource for now — adding a new
    type is rare enough that it goes through seed.py/a migration for v1;
    this endpoint just powers the dropdown in the clothing form.
    """
    with get_session() as session:
        types = session.query(ClothingType).order_by(ClothingType.sort_order).all()
        # Convert to plain Pydantic objects WHILE the session is still open —
        # returning raw ORM objects here would let FastAPI try to read their
        # attributes after `with` has already closed the session, which
        # raises DetachedInstanceError.
        return [ClothingTypeOut.model_validate(t) for t in types]


@router.get("", response_model=list[ClothingItemOut])
def list_clothing(type_slug: str | None = None, status: str | None = None, tag: str | None = None):
    with get_session() as session:
        query = session.query(ClothingItem)
        if type_slug:
            query = query.join(ClothingItem.clothing_type).filter_by(slug=type_slug)
        if status:
            query = query.filter(ClothingItem.status == status)
        if tag:
            query = query.join(ClothingItem.tags).filter(Tag.slug == tag)
        items = query.order_by(ClothingItem.name).all()
        return [clothing_item_to_out(session, i) for i in items]


@router.get("/{item_id}", response_model=ClothingItemOut)
def get_clothing(item_id: int):
    with get_session() as session:
        item = session.get(ClothingItem, item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")
        return clothing_item_to_out(session, item)


@router.post("", response_model=ClothingItemOut, status_code=201)
def create_clothing(payload: ClothingItemIn):
    with get_session() as session:
        if session.query(ClothingItem).filter_by(qr_code=payload.qr_code).first():
            raise HTTPException(409, f"QR code '{payload.qr_code}' is already in use")

        data = payload.model_dump(exclude={"tag_ids"})
        item = ClothingItem(**data)
        if payload.tag_ids:
            item.tags = session.query(Tag).filter(Tag.id.in_(payload.tag_ids)).all()
        session.add(item)
        session.flush()  # populate item.id before we build the response
        return clothing_item_to_out(session, item)


@router.put("/{item_id}", response_model=ClothingItemOut)
def update_clothing(item_id: int, payload: ClothingItemUpdate):
    with get_session() as session:
        item = session.get(ClothingItem, item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")

        updates = payload.model_dump(exclude_unset=True, exclude={"tag_ids"})
        if "qr_code" in updates:
            conflict = (
                session.query(ClothingItem)
                .filter(ClothingItem.qr_code == updates["qr_code"], ClothingItem.id != item_id)
                .first()
            )
            if conflict:
                raise HTTPException(409, f"QR code '{updates['qr_code']}' is already in use")

        for field, value in updates.items():
            setattr(item, field, value)

        if payload.tag_ids is not None:
            item.tags = session.query(Tag).filter(Tag.id.in_(payload.tag_ids)).all()

        session.flush()
        return clothing_item_to_out(session, item)


@router.delete("/{item_id}", status_code=204)
def delete_clothing(item_id: int):
    with get_session() as session:
        item = session.get(ClothingItem, item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")

        has_history = session.query(WearHistory).filter_by(clothing_item_id=item_id).first()
        if has_history:
            raise HTTPException(
                409,
                "This item has wear history and can't be deleted — "
                "set its status to 'retired' or 'donated' instead.",
            )

        # An item can still be sitting in a RECOMMENDED outfit that was
        # never actually confirmed/worn (Section 20 — a recommendation is
        # deliberately not wear history, so it didn't trip the check
        # above). Leaving those OutfitItem rows in place would orphan
        # them, and the next GET /api/recommendation/today would crash
        # trying to serialize a clothing item that no longer exists — so
        # clean those up here rather than blocking a delete that's
        # genuinely safe (nothing was actually worn).
        session.query(OutfitItem).filter_by(clothing_item_id=item_id).delete()

        _delete_photo_file(item)
        session.delete(item)


# --- Photos --------------------------------------------------------------

def _photo_path(item_id: int) -> Path:
    return PHOTO_DIR / f"{item_id}.jpg"


def _delete_photo_file(item: ClothingItem) -> None:
    path = _photo_path(item.id)
    if path.exists():
        path.unlink()


@router.post("/{item_id}/photo", response_model=ClothingItemOut)
async def upload_photo(item_id: int, file: UploadFile = File(...)):
    with get_session() as session:
        item = session.get(ClothingItem, item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")

        raw = await file.read(MAX_UPLOAD_BYTES + 1)
        if len(raw) > MAX_UPLOAD_BYTES:
            raise HTTPException(413, "Photo is too large (8 MB max)")

        try:
            image = Image.open(io.BytesIO(raw))
            image.verify()  # raises if it's not a genuine, intact image
            image = Image.open(io.BytesIO(raw))  # re-open: verify() consumes the file
            image = image.convert("RGB")
        except (UnidentifiedImageError, OSError):
            raise HTTPException(400, "That file isn't a readable image")

        image.thumbnail((MAX_PHOTO_DIMENSION, MAX_PHOTO_DIMENSION))
        dest = _photo_path(item_id)
        image.save(dest, format="JPEG", quality=85, optimize=True)

        item.photo_path = str(dest)
        session.flush()
        return clothing_item_to_out(session, item)


@router.delete("/{item_id}/photo", response_model=ClothingItemOut)
def delete_photo(item_id: int):
    with get_session() as session:
        item = session.get(ClothingItem, item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")
        _delete_photo_file(item)
        item.photo_path = None
        session.flush()
        return clothing_item_to_out(session, item)


# --- Manual wear logging (real automation arrives in Phase 4 & 7) --------

@router.post("/wear", response_model=WearOut, status_code=201)
def log_wear(payload: WearIn):
    """
    Manually record a wear for testing purposes — the actual "Wear This"
    button and QR-scan flows (Phases 4 & 7) will call the same underlying
    pattern, always with an explicit `source`. This endpoint exists so you
    can generate realistic wear history now and see cost-per-wear /
    rotation stats update, before those flows are built.
    """
    with get_session() as session:
        item = session.get(ClothingItem, payload.clothing_item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")

        wear = WearHistory(
            clothing_item_id=payload.clothing_item_id,
            worn_date=payload.worn_date or date.today(),
            source=WearSource.manual_scan,
        )
        session.add(wear)
        session.flush()
        return WearOut.model_validate(wear)


# --- QR code generation (Section 15) --------------------------------------

@router.get("/{item_id}/qr.png")
def get_item_qr_png(item_id: int):
    """
    A single downloadable QR code PNG encoding this item's exact qr_code
    value — print it and stick it on the item. This is what the camera
    (Phase 4/7) reads back to identify the item.
    """
    with get_session() as session:
        item = session.get(ClothingItem, item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")
        png_bytes = qr_generator.generate_qr_png(item.qr_code)
        return Response(
            content=png_bytes,
            media_type="image/png",
            headers={"Content-Disposition": f'attachment; filename="{item.qr_code}.png"'},
        )


class QrSheetRequest(BaseModel):
    item_ids: list[int] | None = None  # None means "all active items"


@router.post("/qr-sheet")
def get_qr_sheet_pdf(payload: QrSheetRequest):
    """
    A printable PDF sheet of QR labels — one per item, each showing the
    code, the item's name, and the QR code text underneath, laid out in a
    grid so a batch of new items can be labeled from a single printout.
    Defaults to every active item if no specific item_ids are given.
    """
    with get_session() as session:
        query = session.query(ClothingItem).filter_by(status="active")
        if payload.item_ids:
            query = query.filter(ClothingItem.id.in_(payload.item_ids))
        items = query.order_by(ClothingItem.name).all()

        if not items:
            raise HTTPException(404, "No matching clothing items found to generate labels for")

        pdf_bytes = qr_generator.generate_label_sheet_pdf(
            [{"qr_code": i.qr_code, "name": i.name} for i in items]
        )
        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": 'attachment; filename="wardrobe-qr-labels.pdf"'},
        )
