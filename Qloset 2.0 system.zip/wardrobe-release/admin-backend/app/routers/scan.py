"""
Wardrobe System — QR scan endpoint.

Ties app/qr_scanner.py (camera + decode) to the clothing database. This is
deliberately a single "scan and look up" action rather than separate
"start scanning" / "poll for result" endpoints — camera scans here are
short (a few seconds, bounded by timeout), so a normal synchronous HTTP
request is simpler than the polling/websocket machinery a longer-running
scan would need. Revisit this if real-world testing shows people needing
longer than ~15s to get a code in frame.

Every outcome (found, unknown code, no code detected, camera unavailable)
comes back as HTTP 200 with a `status` field — these are all expected,
routine outcomes for a scan attempt, not server errors. Section 23 asks
for graceful handling of "camera unavailable" and "unknown QR code"
specifically; encoding them as normal response data (rather than 5xx/4xx)
is what lets the eventual kiosk UI show a friendly message instead of
looking broken.
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from datetime import date

from app.qr_scanner import ScanStatus, mjpeg_preview_frames, scan_once
from app.serializers import clothing_item_to_out
from app.schemas import ClothingItemOut
from db.database import get_session
from db.models import ClothingItem, WearHistory, WearSource

router = APIRouter(prefix="/api/scan", tags=["scan"])


class ScanResponse(BaseModel):
    status: str  # "detected" | "unknown_code" | "timeout" | "camera_unavailable"
    qr_code: str | None = None
    item: ClothingItemOut | None = None


class ScanConfirmRequest(BaseModel):
    clothing_item_id: int


class ScanConfirmResponse(BaseModel):
    wear_id: int
    item: ClothingItemOut


@router.post("", response_model=ScanResponse)
def scan(timeout_seconds: float | None = None):
    kwargs = {"timeout_seconds": timeout_seconds} if timeout_seconds is not None else {}
    result = scan_once(**kwargs)

    if result.status == ScanStatus.camera_unavailable:
        return ScanResponse(status="camera_unavailable")
    if result.status == ScanStatus.timeout:
        return ScanResponse(status="timeout")

    # result.status == detected
    with get_session() as session:
        item = session.query(ClothingItem).filter_by(qr_code=result.qr_code).one_or_none()
        if not item:
            return ScanResponse(status="unknown_code", qr_code=result.qr_code)
        return ScanResponse(status="detected", qr_code=result.qr_code, item=clothing_item_to_out(session, item))


@router.get("/preview.mjpg")
def scan_preview():
    """
    Live camera preview for the kiosk's "scan the item you're wearing"
    screen, so you can tell whether you're actually in frame instead of
    guessing. Streams frames from whichever scan_once() call is currently
    holding the camera open (see app/qr_scanner.py) — this endpoint never
    opens its own camera handle, so it can't conflict with an in-progress
    scan. If nothing is scanning right now, the stream just ends quickly
    rather than hanging open.
    """
    return StreamingResponse(
        mjpeg_preview_frames(),
        media_type="multipart/x-mixed-replace; boundary=frame",
    )


@router.post("/confirm", response_model=ScanConfirmResponse, status_code=201)
def confirm_scanned_item(payload: ScanConfirmRequest):
    """
    The second half of the "CHANGE" workflow (Section 11): after `POST
    /api/scan` identifies an item, the kiosk shows it for confirmation,
    then calls this to actually record it as worn today. Kept as a
    separate step from the raw scan so a misidentified item can be
    re-scanned before anything is written — scanning alone never writes
    to wear_history, only this confirmation does (Section 20).

    Not tied to a specific outfit_id — a manually scanned wear stands on
    its own, exactly per the WearHistory schema's outfit_id being nullable
    for source=manual_scan.
    """
    with get_session() as session:
        item = session.get(ClothingItem, payload.clothing_item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")

        wear = WearHistory(
            clothing_item_id=item.id,
            worn_date=date.today(),
            source=WearSource.manual_scan,
        )
        session.add(wear)
        session.flush()
        return ScanConfirmResponse(wear_id=wear.id, item=clothing_item_to_out(session, item))
