"""
Wardrobe System — statistics & history API (Phase 8).
"""

from fastapi import APIRouter, HTTPException

from app import history as history_module
from app import wardrobe_stats
from db.database import get_session
from db.models import ClothingItem

router = APIRouter(prefix="/api/statistics", tags=["statistics"])


@router.get("/overview")
def overview():
    with get_session() as session:
        return wardrobe_stats.wardrobe_overview(session)


@router.get("/wears-over-time")
def wears_over_time(days: int = 90):
    with get_session() as session:
        return wardrobe_stats.wears_over_time(session, days=days)


@router.get("/needs-attention")
def needs_attention(unworn_days: int = 90):
    with get_session() as session:
        return wardrobe_stats.needs_attention(session, unworn_days_threshold=unworn_days)


@router.get("/item/{item_id}")
def item_detail(item_id: int):
    with get_session() as session:
        item = session.get(ClothingItem, item_id)
        if not item:
            raise HTTPException(404, "Clothing item not found")
        return wardrobe_stats.item_detail_stats(session, item)


@router.get("/history")
def history(days: int = 30):
    with get_session() as session:
        return history_module.day_history(session, days=days)


@router.get("/history/sundays")
def sunday_history(weeks: int = 26):
    with get_session() as session:
        return history_module.sunday_history(session, weeks=weeks)
