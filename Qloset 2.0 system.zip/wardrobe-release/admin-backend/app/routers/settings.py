"""
Wardrobe System — settings API (recommendation weights, for now).

A minimal read/write API rather than a full admin page yet — enough to
tune and test scoring behavior now; a dedicated settings screen in the
admin UI is a natural, low-effort addition whenever it's wanted, since it
would just be a thin form over these same two endpoints.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app import settings as settings_module
from db.database import get_session

router = APIRouter(prefix="/api/settings", tags=["settings"])


class SettingUpdate(BaseModel):
    value: float


@router.get("")
def list_settings():
    with get_session() as session:
        return settings_module.get_all_settings(session)


@router.put("/{key}")
def update_setting(key: str, payload: SettingUpdate):
    with get_session() as session:
        try:
            settings_module.set_setting(session, key, payload.value)
        except KeyError as exc:
            raise HTTPException(404, str(exc))
        session.flush()
        return {key: payload.value}
