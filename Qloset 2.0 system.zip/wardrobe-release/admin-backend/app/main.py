"""
Wardrobe System — admin web app entrypoint.

Run with:
    uvicorn app.main:app --reload --host 0.0.0.0 --port 8080

Runs identically in local dev (Windows/Mac, WARDROBE_DB_PATH pointing at a
local file) and, later, as a systemd-managed service on the UNO Q at
whatever static LAN IP you've assigned it — no App Lab / Bridge
dependency here, since none of this needs the MCU.
"""

import logging

from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.routers import clothing, recommendation, scan, settings, statistics, tags, weather
from db.database import init_db

logging.basicConfig(level=logging.INFO)

app = FastAPI(title="Wardrobe System — Admin")

# Create tables on first run in a fresh dev environment. In normal use,
# schema changes should go through `alembic upgrade head` instead — this
# is just a safety net so a brand new checkout doesn't 500 on first request.
init_db()

app.include_router(clothing.router)
app.include_router(tags.router)
app.include_router(scan.router)
app.include_router(weather.router)
app.include_router(recommendation.router)
app.include_router(settings.router)
app.include_router(statistics.router)

app.mount("/photos", StaticFiles(directory="data/photos"), name="photos")

templates = Jinja2Templates(directory="app/templates")


@app.get("/")
def home():
    return RedirectResponse(url="/clothing")


@app.get("/clothing")
def clothing_list_page(request: Request):
    return templates.TemplateResponse(request, "clothing_list.html", {})


@app.get("/clothing/new")
def clothing_new_page(request: Request):
    return templates.TemplateResponse(request, "clothing_form.html", {"item_id": None})


@app.get("/clothing/{item_id}/edit")
def clothing_edit_page(request: Request, item_id: int):
    return templates.TemplateResponse(request, "clothing_form.html", {"item_id": item_id})


@app.get("/tags")
def tags_page(request: Request):
    return templates.TemplateResponse(request, "tags.html", {})


@app.get("/statistics")
def statistics_page(request: Request):
    return templates.TemplateResponse(request, "statistics.html", {})


@app.get("/history")
def history_page(request: Request):
    return templates.TemplateResponse(request, "history.html", {})
