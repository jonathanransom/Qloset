"""
Wardrobe System — outfit recommendation engine.

Design (matches the Phase 1 discussion):

  1. ELIGIBILITY (hard gate, not scored): an item must be `active`, must
     carry at least one tag required by today's schedule (or the active
     special-event override), and — if weather data is available — its
     min/max temp and rain_ok must not conflict with today's forecast.
     Anything that fails this never reaches scoring.

  2. SCORING (additive, every term explained below):

       score = rotation_score
             + weather_fit_score
             + sunday_bonus            (Sundays only)
             + preference_score
             - recent_wear_penalty
             - overuse_penalty

     Every weight is read from app/settings.py, so tuning behavior means
     changing a number in the `settings` table, not this file.

  3. SELECTION: highest score wins per outfit slot (top, bottom, ...
     future: footwear, outerwear, accessory). To avoid rigid,
     always-the-same-tiebreak behavior, items scoring within
     `tie_margin` points of the top score are treated as tied and one is
     chosen at random among them.

  4. RECORDING: the result is saved as an Outfit + OutfitItem rows — this
     is what the system RECOMMENDED. Nothing here ever writes to
     wear_history — that only happens via explicit confirmation or a scan
     (Section 20), built in later phases.
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field
from datetime import date, timedelta

from app import settings as settings_module
from app import stats
from app.weather import WeatherData, get_weather
from db.models import (
    ClothingItem,
    ClothingType,
    Outfit,
    OutfitItem,
    ScheduleRule,
    SpecialEvent,
)

log = logging.getLogger("wardrobe.recommendation")

REQUIRED_SLOTS = ["top", "bottom"]  # minimum viable outfit, per Section 7


@dataclass
class ScoredItem:
    item: ClothingItem
    total: float
    breakdown: dict[str, float] = field(default_factory=dict)


def todays_required_tags(session, today: date) -> tuple[set[int], bool]:
    """
    Returns (required_tag_ids, is_special_event). An item is eligible for
    today if it has ANY tag in this set.

    Special events with overrides_day=True REPLACE the normal weekly
    schedule for any date they cover, rather than adding to it — e.g. a
    week of vacation overrides your normal Mon-Fri work schedule entirely.
    """
    event = (
        session.query(SpecialEvent)
        .filter(
            SpecialEvent.start_date <= today,
            SpecialEvent.end_date >= today,
            SpecialEvent.overrides_day.is_(True),
        )
        .first()
    )
    if event:
        return {t.id for t in event.tags}, True

    rule = session.query(ScheduleRule).filter_by(day_of_week=today.weekday()).first()
    if not rule:
        return set(), False
    return {t.id for t in rule.tags}, False


def _weather_gate_ok(item: ClothingItem, weather: WeatherData | None) -> bool:
    """Hard pass/fail — see scoring for how well-centered items are preferred among survivors."""
    if weather is None or weather.temp is None:
        return True  # no weather data: don't block on it, per Section 23's degrade-gracefully rule
    if item.min_temp_f is not None and weather.temp < item.min_temp_f:
        return False
    if item.max_temp_f is not None and weather.temp > item.max_temp_f:
        return False
    if item.rain_ok is False and weather.rain_probability is not None and weather.rain_probability >= 50:
        return False
    return True


def eligible_items(session, slot: str, required_tag_ids: set[int], weather: WeatherData | None) -> list[ClothingItem]:
    query = (
        session.query(ClothingItem)
        .join(ClothingItem.clothing_type)
        .filter(ClothingType.outfit_slot == slot, ClothingItem.status == "active")
    )
    candidates = query.all()
    if required_tag_ids:
        candidates = [c for c in candidates if {t.id for t in c.tags} & required_tag_ids]
    return [c for c in candidates if _weather_gate_ok(c, weather)]


def _thirty_days_ago(today: date) -> date:
    return today - timedelta(days=30)


def score_item(session, item: ClothingItem, today: date, weather: WeatherData | None, w: dict) -> ScoredItem:
    breakdown: dict[str, float] = {}

    # --- Rotation: reward items unworn longer, capped so a shirt unworn
    # for a year doesn't permanently dominate every recommendation.
    days_unworn = stats.days_since_worn(session, item.id)
    cap = w["rotation_cap_days"]
    rotation_fraction = 1.0 if days_unworn is None else min(days_unworn, cap) / cap
    breakdown["rotation"] = w["weight_rotation"] * rotation_fraction

    # --- Weather fit: among items that already passed the hard gate,
    # prefer ones whose comfort range is centered on today's temp over
    # ones just barely squeaking by at the edge of their range. Items
    # with no min/max set are "works with anything" — full credit.
    if weather and weather.temp is not None and item.min_temp_f is not None and item.max_temp_f is not None:
        span = max(item.max_temp_f - item.min_temp_f, 1.0)
        center = (item.max_temp_f + item.min_temp_f) / 2
        distance_from_center = abs(weather.temp - center) / (span / 2)
        breakdown["weather_fit"] = w["weight_weather"] * max(0.0, 1 - distance_from_center)
    else:
        breakdown["weather_fit"] = w["weight_weather"]  # neutral/full credit — no data to penalize with

    # --- Sunday/church rotation (Section 8): only active on Sundays,
    # and specifically tracks Sundays, not wears on any day.
    if today.weekday() == 6:
        weeks = stats.weeks_since_last_worn_on_weekday(session, item.id, weekday=6)
        sunday_cap = w["sunday_rotation_cap_weeks"]
        sunday_fraction = 1.0 if weeks is None else min(weeks, sunday_cap) / sunday_cap
        breakdown["sunday_bonus"] = w["weight_sunday"] * sunday_fraction
    else:
        breakdown["sunday_bonus"] = 0.0

    # --- Preference: your manual per-item nudge, direct passthrough scaled by weight.
    breakdown["preference"] = w["weight_preference"] * item.preference_boost

    # --- Recent-wear penalty: steep drop-off for anything worn very recently.
    recent_days = w["recent_wear_days"]
    if days_unworn is not None and days_unworn < recent_days:
        breakdown["recent_wear_penalty"] = -w["weight_recent_penalty"] * (recent_days - days_unworn) / recent_days
    else:
        breakdown["recent_wear_penalty"] = 0.0

    # --- Overuse penalty: simple v1 — scales with raw wears in the last
    # 30 days, capped. (A v2 could compare against the average for this
    # slot/type instead of an absolute cap — noted as a future refinement,
    # not needed to get useful rotation behavior now.)
    wears_30 = stats.wears_since(session, item.id, _thirty_days_ago(today))
    overuse_cap = w["overuse_wears_cap"]
    breakdown["overuse_penalty"] = -w["weight_overuse_penalty"] * min(wears_30, overuse_cap) / overuse_cap

    total = sum(breakdown.values())
    return ScoredItem(item=item, total=total, breakdown=breakdown)


def score_candidates(session, candidates: list[ClothingItem], today: date, weather, w: dict) -> list[ScoredItem]:
    scored = [score_item(session, c, today, weather, w) for c in candidates]
    return sorted(scored, key=lambda s: s.total, reverse=True)


def select_winner(scored: list[ScoredItem], tie_margin: float) -> ScoredItem | None:
    if not scored:
        return None
    top_score = scored[0].total
    tied = [s for s in scored if top_score - s.total <= tie_margin]
    return random.choice(tied)


def generate_recommendation(session, target_date: date | None = None, force: bool = False) -> tuple[Outfit | None, dict]:
    """
    Returns (outfit_or_none, debug_info). debug_info always includes the
    full per-candidate score breakdown for every slot, regardless of
    success — this is what makes the algorithm inspectable rather than a
    black box (Section 19), and it's what the recommend_test.py CLI prints.

    If an Outfit already exists for target_date and force=False, returns
    the existing one rather than generating a new one (a day should have
    one stable recommendation unless you explicitly ask to regenerate it).
    """
    today = target_date or date.today()
    w = settings_module.get_all_settings(session)

    existing = session.query(Outfit).filter_by(date=today).first()
    if existing and not force:
        return existing, {"note": "existing recommendation returned; pass force=True to regenerate"}

    required_tag_ids, is_special_event = todays_required_tags(session, today)
    weather, weather_source = get_weather()

    debug: dict = {
        "date": today.isoformat(),
        "required_tag_ids": sorted(required_tag_ids),
        "is_special_event": is_special_event,
        "weather_source": weather_source,
        "slots": {},
    }

    chosen: dict[str, ScoredItem] = {}
    for slot in REQUIRED_SLOTS:
        candidates = eligible_items(session, slot, required_tag_ids, weather)
        scored = score_candidates(session, candidates, today, weather, w)
        debug["slots"][slot] = [
            {
                "item_id": s.item.id,
                "name": s.item.name,
                "total": round(s.total, 2),
                **{k: round(v, 2) for k, v in s.breakdown.items()},
            }
            for s in scored
        ]
        winner = select_winner(scored, w["tie_margin"])
        if winner:
            chosen[slot] = winner

    if not all(slot in chosen for slot in REQUIRED_SLOTS):
        missing = [s for s in REQUIRED_SLOTS if s not in chosen]
        debug["error"] = f"No eligible item found for slot(s): {', '.join(missing)}"
        log.warning(debug["error"])
        return None, debug

    if existing and force:
        session.query(OutfitItem).filter_by(outfit_id=existing.id).delete()
        outfit = existing
    else:
        outfit = Outfit(date=today)
        session.add(outfit)
    session.flush()

    for slot, scored_item in chosen.items():
        session.add(OutfitItem(outfit_id=outfit.id, clothing_item_id=scored_item.item.id, slot=slot))

    session.flush()
    return outfit, debug
