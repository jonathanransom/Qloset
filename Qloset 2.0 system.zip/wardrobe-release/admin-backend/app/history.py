"""
Wardrobe System — recommendation-vs-actual history (Phase 8, Section 15's
"History" panel + Section 8's Sunday history).

For each date, this pairs up what was RECOMMENDED (Outfit/OutfitItem) with
what was ACTUALLY WORN (WearHistory) — the whole point of keeping those
two tables separate since Phase 3 (Section 20) is that this comparison is
possible and meaningful. `followed` is:
  - None   — no wear was ever recorded for that date (recommended, but
             we don't know what actually happened)
  - True   — every wear recorded that date came from confirming the
             recommendation (no manual_scan rows that day)
  - False  — at least one item that day was recorded via manual_scan,
             meaning the recommendation was overridden
"""

from __future__ import annotations

from datetime import date, timedelta

from sqlalchemy.orm import Session

from db.models import Outfit, WearHistory, WearSource


def day_history(session: Session, days: int = 30) -> list[dict]:
    start = date.today() - timedelta(days=days - 1)

    outfits = (
        session.query(Outfit)
        .filter(Outfit.date >= start)
        .order_by(Outfit.date.desc())
        .all()
    )
    outfits_by_date = {o.date: o for o in outfits}

    wears = (
        session.query(WearHistory)
        .filter(WearHistory.worn_date >= start)
        .order_by(WearHistory.worn_date.desc())
        .all()
    )
    wears_by_date: dict[date, list[WearHistory]] = {}
    for w in wears:
        wears_by_date.setdefault(w.worn_date, []).append(w)

    all_dates = sorted(set(outfits_by_date) | set(wears_by_date), reverse=True)

    result = []
    for d in all_dates:
        outfit = outfits_by_date.get(d)
        day_wears = wears_by_date.get(d, [])

        recommended = (
            {oi.slot: oi.clothing_item.name for oi in outfit.items} if outfit else None
        )
        actual = [w.clothing_item.name for w in day_wears]

        if not day_wears:
            followed = None
        else:
            followed = all(w.source == WearSource.recommended_confirmed for w in day_wears)

        result.append(
            {
                "date": d.isoformat(),
                "day_of_week": d.strftime("%A"),
                "recommended": recommended,
                "actual": actual,
                "followed": followed,
            }
        )
    return result


def sunday_history(session: Session, weeks: int = 26) -> list[dict]:
    """Section 8: Sunday-specific view, filtered from the same day_history data."""
    full = day_history(session, days=weeks * 7)
    return [row for row in full if row["day_of_week"] == "Sunday"]
