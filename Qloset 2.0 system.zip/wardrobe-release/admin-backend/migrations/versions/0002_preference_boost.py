"""add preference_boost to clothing_items

Revision ID: 0002_preference_boost
Revises: 0001_initial_schema
Create Date: 2026-09-26

"""
from alembic import op
import sqlalchemy as sa

revision = "0002_preference_boost"
down_revision = "0001_initial_schema"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("clothing_items") as batch_op:
        batch_op.add_column(
            sa.Column("preference_boost", sa.Float, nullable=False, server_default="0")
        )


def downgrade() -> None:
    with op.batch_alter_table("clothing_items") as batch_op:
        batch_op.drop_column("preference_boost")
