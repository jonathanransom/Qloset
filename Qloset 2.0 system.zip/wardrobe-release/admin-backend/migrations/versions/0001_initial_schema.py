"""initial schema

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-09-25

"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "clothing_types",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(100), nullable=False, unique=True),
        sa.Column("slug", sa.String(100), nullable=False, unique=True),
        sa.Column("outfit_slot", sa.String(50), nullable=False),
        sa.Column("sort_order", sa.Integer, nullable=False, server_default="0"),
    )

    op.create_table(
        "tags",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(100), nullable=False, unique=True),
        sa.Column("slug", sa.String(100), nullable=False, unique=True),
        sa.Column("category", sa.String(50)),
    )

    op.create_table(
        "clothing_items",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("qr_code", sa.String(100), nullable=False, unique=True),
        sa.Column("clothing_type_id", sa.Integer, sa.ForeignKey("clothing_types.id"), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("brand", sa.String(100)),
        sa.Column("size", sa.String(50)),
        sa.Column("color", sa.String(50)),
        sa.Column("pattern", sa.String(50)),
        sa.Column("material", sa.String(100)),
        sa.Column("purchase_date", sa.Date),
        sa.Column("purchase_price", sa.Float),
        sa.Column(
            "status",
            sa.Enum("active", "laundry", "retired", "donated", name="clothingstatus"),
            nullable=False,
            server_default="active",
        ),
        sa.Column("photo_path", sa.String(500)),
        sa.Column("min_temp_f", sa.Float),
        sa.Column("max_temp_f", sa.Float),
        sa.Column("rain_ok", sa.Boolean),
        sa.Column("notes", sa.Text),
        sa.Column("created_at", sa.DateTime, nullable=False),
        sa.Column("updated_at", sa.DateTime, nullable=False),
    )
    op.create_index("ix_clothing_items_qr_code", "clothing_items", ["qr_code"])

    op.create_table(
        "clothing_tags",
        sa.Column("clothing_item_id", sa.Integer, sa.ForeignKey("clothing_items.id"), primary_key=True),
        sa.Column("tag_id", sa.Integer, sa.ForeignKey("tags.id"), primary_key=True),
    )

    op.create_table(
        "schedule_rules",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("day_of_week", sa.Integer, nullable=False, unique=True),
        sa.Column("label", sa.String(100)),
    )

    op.create_table(
        "schedule_rule_tags",
        sa.Column("schedule_rule_id", sa.Integer, sa.ForeignKey("schedule_rules.id"), primary_key=True),
        sa.Column("tag_id", sa.Integer, sa.ForeignKey("tags.id"), primary_key=True),
    )

    op.create_table(
        "special_events",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("start_date", sa.Date, nullable=False),
        sa.Column("end_date", sa.Date, nullable=False),
        sa.Column(
            "event_type",
            sa.Enum("holiday", "vacation", "sick", "event", name="specialeventtype"),
            nullable=False,
        ),
        sa.Column("overrides_day", sa.Boolean, nullable=False, server_default=sa.true()),
    )

    op.create_table(
        "special_event_tags",
        sa.Column("special_event_id", sa.Integer, sa.ForeignKey("special_events.id"), primary_key=True),
        sa.Column("tag_id", sa.Integer, sa.ForeignKey("tags.id"), primary_key=True),
    )

    op.create_table(
        "weather_history",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("fetched_at", sa.DateTime, nullable=False),
        sa.Column("temp", sa.Float),
        sa.Column("feels_like", sa.Float),
        sa.Column("condition", sa.String(100)),
        sa.Column("rain_probability", sa.Float),
        sa.Column("precipitation", sa.Float),
        sa.Column("wind", sa.Float),
        sa.Column("humidity", sa.Float),
        sa.Column("high", sa.Float),
        sa.Column("low", sa.Float),
        sa.Column("raw_json", sa.Text),
    )

    op.create_table(
        "outfits",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("date", sa.Date, nullable=False, unique=True),
        sa.Column("generated_at", sa.DateTime, nullable=False),
        sa.Column("weather_history_id", sa.Integer, sa.ForeignKey("weather_history.id")),
    )

    op.create_table(
        "outfit_items",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("outfit_id", sa.Integer, sa.ForeignKey("outfits.id"), nullable=False),
        sa.Column("clothing_item_id", sa.Integer, sa.ForeignKey("clothing_items.id"), nullable=False),
        sa.Column("slot", sa.String(50), nullable=False),
    )

    op.create_table(
        "wear_history",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("clothing_item_id", sa.Integer, sa.ForeignKey("clothing_items.id"), nullable=False),
        sa.Column("worn_date", sa.Date, nullable=False),
        sa.Column("outfit_id", sa.Integer, sa.ForeignKey("outfits.id")),
        sa.Column(
            "source",
            sa.Enum("recommended_confirmed", "manual_scan", name="wearsource"),
            nullable=False,
        ),
        sa.Column("created_at", sa.DateTime, nullable=False),
    )

    op.create_table(
        "settings",
        sa.Column("key", sa.String(100), primary_key=True),
        sa.Column("value", sa.Text, nullable=False),
        sa.Column("updated_at", sa.DateTime, nullable=False),
    )


def downgrade() -> None:
    op.drop_table("settings")
    op.drop_table("wear_history")
    op.drop_table("outfit_items")
    op.drop_table("outfits")
    op.drop_table("weather_history")
    op.drop_table("special_event_tags")
    op.drop_table("special_events")
    op.drop_table("schedule_rule_tags")
    op.drop_table("schedule_rules")
    op.drop_table("clothing_tags")
    op.drop_index("ix_clothing_items_qr_code", table_name="clothing_items")
    op.drop_table("clothing_items")
    op.drop_table("tags")
    op.drop_table("clothing_types")
