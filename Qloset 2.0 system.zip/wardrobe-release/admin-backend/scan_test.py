"""
Wardrobe System — standalone QR scan test.

Run this directly to verify the camera + QR decoding works, independent of
the web server, before relying on it from the API or (in Phase 7) the
physical button workflow. Useful for isolating "is it the camera/library"
from "is it the web app" when something goes wrong.

Usage:
    python scan_test.py                 # scans, looks up in the DB
    python scan_test.py --timeout 20    # wait up to 20s for a code
"""

import argparse

from app.qr_scanner import ScanStatus, scan_once
from db.database import get_session
from db.models import ClothingItem


def main():
    parser = argparse.ArgumentParser(description="Test the camera + QR pipeline")
    parser.add_argument("--timeout", type=float, default=None, help="Seconds to wait for a code")
    args = parser.parse_args()

    print("Hold a QR code in front of the camera...")
    kwargs = {"timeout_seconds": args.timeout} if args.timeout is not None else {}
    result = scan_once(**kwargs)

    if result.status == ScanStatus.camera_unavailable:
        print("ERROR: camera could not be opened. Check WARDROBE_CAMERA_INDEX and that no other")
        print("program is using it, then check `python -c \"import cv2; print(cv2.__version__)\"`.")
        return

    if result.status == ScanStatus.timeout:
        print("No QR code detected within the timeout. Try again with --timeout 20,")
        print("or check camera focus/lighting.")
        return

    print(f"Decoded: {result.qr_code}")
    with get_session() as session:
        item = session.query(ClothingItem).filter_by(qr_code=result.qr_code).one_or_none()
        if item:
            print(f"Matched clothing item: {item.name} (id={item.id}, status={item.status})")
        else:
            print("No clothing item in the database has this QR code.")


if __name__ == "__main__":
    main()
