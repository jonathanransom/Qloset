"""
Wardrobe System — database engine & session factory.

The DB location is read from the WARDROBE_DB_PATH environment variable so
it's never hard-coded, and so the same code works both on the UNO Q and in
local dev mode on a laptop (per the "must run without all hardware
connected" requirement). Defaults to ./data/wardrobe.db if unset, which is
convenient for local development.
"""

import os
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from db.models import Base

DB_PATH = os.environ.get("WARDROBE_DB_PATH", "data/wardrobe.db")

# Make sure the parent directory exists (e.g. ./data/) so SQLite doesn't
# fail on first run just because the folder isn't there yet.
Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(f"sqlite:///{DB_PATH}", echo=False, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def init_db() -> None:
    """
    Create all tables if they don't exist yet.
    Only used for the very first run / local dev — once Alembic migrations
    exist (this Phase), schema changes should go through a migration, not
    through this function, to keep history tracked and reversible.
    """
    Base.metadata.create_all(bind=engine)


@contextmanager
def get_session():
    """
    Usage:
        with get_session() as session:
            session.add(some_object)
    Commits on success, rolls back on exception, always closes.
    """
    session: Session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
