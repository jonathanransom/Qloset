"""
Wardrobe System — database models (SQLAlchemy ORM)

This module defines the schema proposed in Phase 1. Key design points,
carried over from that discussion:

  - `ClothingType.outfit_slot` (top / bottom / footwear / outerwear / accessory)
    is what makes adding new clothing categories (shoes, jackets, hats...)
    a data change, not a code change.
  - Weather suitability lives as simple nullable columns on ClothingItem
    (min/max temp, rain_ok) per the "don't over-engineer weather" instruction.
    Tags and day-rules, which are genuinely many-to-many, get real join tables.
  - `Outfit`/`OutfitItem` record what the system RECOMMENDED.
    `WearHistory` records what was ACTUALLY worn. These are never the same
    table, and nothing writes to WearHistory automatically — see `source`
    on WearHistory, which is only ever set by the "Wear This" confirmation
    endpoint or the manual QR-scan endpoint (built in later phases).
  - cost-per-wear, days-since-worn, etc. are deliberately NOT columns here —
    they're computed from purchase_price and WearHistory counts wherever
    they're needed (see stats helpers in a later phase).
"""

from __future__ import annotations

import enum
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Table,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Clothing types & items
# ---------------------------------------------------------------------------

class ClothingType(Base):
    """
    A clothing category (Shirt, Polo Shirt, Pants, Shorts, ...).
    New categories (Shoes, Jacket, Hat, ...) are added as ROWS here, never
    as code changes — that's what satisfies the "don't hard-code around
    shirts and pants" requirement.
    """
    __tablename__ = "clothing_types"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    # Which slot in an outfit this type fills. The recommendation engine
    # (Phase 6) asks "what's eligible for slot X", never "is this a shirt".
    outfit_slot: Mapped[str] = mapped_column(String(50), nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    items: Mapped[list["ClothingItem"]] = relationship(back_populates="clothing_type")


class ClothingStatus(str, enum.Enum):
    active = "active"
    laundry = "laundry"
    retired = "retired"
    donated = "donated"


clothing_tags = Table(
    "clothing_tags",
    Base.metadata,
    Column("clothing_item_id", ForeignKey("clothing_items.id"), primary_key=True),
    Column("tag_id", ForeignKey("tags.id"), primary_key=True),
)


class ClothingItem(Base):
    __tablename__ = "clothing_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    qr_code: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    clothing_type_id: Mapped[int] = mapped_column(ForeignKey("clothing_types.id"), nullable=False)

    name: Mapped[str] = mapped_column(String(200), nullable=False)
    brand: Mapped[str | None] = mapped_column(String(100))
    size: Mapped[str | None] = mapped_column(String(50))
    color: Mapped[str | None] = mapped_column(String(50))
    pattern: Mapped[str | None] = mapped_column(String(50))
    material: Mapped[str | None] = mapped_column(String(100))

    purchase_date: Mapped[date | None] = mapped_column(Date)
    purchase_price: Mapped[float | None] = mapped_column(Float)

    status: Mapped[ClothingStatus] = mapped_column(
        Enum(ClothingStatus), default=ClothingStatus.active, nullable=False
    )
    photo_path: Mapped[str | None] = mapped_column(String(500))

    # Weather suitability — simple v1 model, per Phase 1 discussion.
    min_temp_f: Mapped[float | None] = mapped_column(Float)
    max_temp_f: Mapped[float | None] = mapped_column(Float)
    rain_ok: Mapped[bool | None] = mapped_column(Boolean)

    # Manual scoring nudge for the recommendation engine (Phase 6) — e.g. a
    # sentimental favorite you want to see a little more often, or an item
    # you want to phase out gradually without retiring it outright. Neutral
    # (0) by default; typically small values like -3..+3.
    preference_boost: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)

    notes: Mapped[str | None] = mapped_column(Text)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    clothing_type: Mapped[ClothingType] = relationship(back_populates="items")
    tags: Mapped[list["Tag"]] = relationship(secondary=clothing_tags, back_populates="clothing_items")
    wear_records: Mapped[list["WearHistory"]] = relationship(back_populates="clothing_item")


# ---------------------------------------------------------------------------
# Tags
# ---------------------------------------------------------------------------

class Tag(Base):
    """
    User-defined tags (Work, Casual, Church, Saturday, Holiday, Vacation,
    Formal, Business Casual, Hot Weather, Cold Weather, Rain, or anything
    else you add). `category` is an optional grouping hint for the admin UI
    (e.g. "day", "occasion", "weather", "custom") — it has no effect on
    matching logic, which treats all tags the same.
    """
    __tablename__ = "tags"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    category: Mapped[str | None] = mapped_column(String(50))

    clothing_items: Mapped[list[ClothingItem]] = relationship(
        secondary=clothing_tags, back_populates="tags"
    )


# ---------------------------------------------------------------------------
# Weekly schedule & exceptions
# ---------------------------------------------------------------------------

schedule_rule_tags = Table(
    "schedule_rule_tags",
    Base.metadata,
    Column("schedule_rule_id", ForeignKey("schedule_rules.id"), primary_key=True),
    Column("tag_id", ForeignKey("tags.id"), primary_key=True),
)


class ScheduleRule(Base):
    """
    'On day X, an eligible item must carry at least one of these tags.'
    One row per day of week (0=Monday .. 6=Sunday), each linked to the
    tags required that day via schedule_rule_tags. This is what lets you
    reconfigure "Friday = Business Casual instead of Work" from the web
    GUI instead of editing code.
    """
    __tablename__ = "schedule_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    day_of_week: Mapped[int] = mapped_column(Integer, unique=True, nullable=False)  # 0=Mon..6=Sun
    label: Mapped[str | None] = mapped_column(String(100))

    tags: Mapped[list[Tag]] = relationship(secondary=schedule_rule_tags)


special_event_tags = Table(
    "special_event_tags",
    Base.metadata,
    Column("special_event_id", ForeignKey("special_events.id"), primary_key=True),
    Column("tag_id", ForeignKey("tags.id"), primary_key=True),
)


class SpecialEventType(str, enum.Enum):
    holiday = "holiday"
    vacation = "vacation"
    sick = "sick"
    event = "event"


class SpecialEvent(Base):
    """
    An exception to the normal weekly schedule over a date range
    (holiday, vacation, wedding, conference, sick day, ...).
    When `overrides_day` is true, this replaces the normal ScheduleRule
    for any date it covers rather than adding to it.
    """
    __tablename__ = "special_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    event_type: Mapped[SpecialEventType] = mapped_column(Enum(SpecialEventType), nullable=False)
    overrides_day: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    tags: Mapped[list[Tag]] = relationship(secondary=special_event_tags)


# ---------------------------------------------------------------------------
# Recommendations vs. actual wear (Section 20 — kept strictly separate)
# ---------------------------------------------------------------------------

class Outfit(Base):
    """What the system RECOMMENDED for a given date. Never implies wear."""
    __tablename__ = "outfits"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    date: Mapped[date] = mapped_column(Date, unique=True, nullable=False)
    generated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    weather_history_id: Mapped[int | None] = mapped_column(ForeignKey("weather_history.id"))

    items: Mapped[list["OutfitItem"]] = relationship(back_populates="outfit")


class OutfitItem(Base):
    __tablename__ = "outfit_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    outfit_id: Mapped[int] = mapped_column(ForeignKey("outfits.id"), nullable=False)
    clothing_item_id: Mapped[int] = mapped_column(ForeignKey("clothing_items.id"), nullable=False)
    slot: Mapped[str] = mapped_column(String(50), nullable=False)

    outfit: Mapped[Outfit] = relationship(back_populates="items")
    clothing_item: Mapped[ClothingItem] = relationship()


class WearSource(str, enum.Enum):
    recommended_confirmed = "recommended_confirmed"  # "Wear This" button
    manual_scan = "manual_scan"                       # scanned a different item


class WearHistory(Base):
    """
    What was ACTUALLY worn. A row is written here ONLY by the
    "Wear This" confirmation handler or the manual QR-scan handler
    (both built in later phases) — never automatically from a
    recommendation being generated.
    """
    __tablename__ = "wear_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    clothing_item_id: Mapped[int] = mapped_column(ForeignKey("clothing_items.id"), nullable=False)
    worn_date: Mapped[date] = mapped_column(Date, nullable=False)
    outfit_id: Mapped[int | None] = mapped_column(ForeignKey("outfits.id"))
    source: Mapped[WearSource] = mapped_column(Enum(WearSource), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    clothing_item: Mapped[ClothingItem] = relationship(back_populates="wear_records")
    outfit: Mapped[Outfit | None] = relationship()


# ---------------------------------------------------------------------------
# Weather cache/log & settings
# ---------------------------------------------------------------------------

class WeatherHistory(Base):
    __tablename__ = "weather_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    temp: Mapped[float | None] = mapped_column(Float)
    feels_like: Mapped[float | None] = mapped_column(Float)
    condition: Mapped[str | None] = mapped_column(String(100))
    rain_probability: Mapped[float | None] = mapped_column(Float)
    precipitation: Mapped[float | None] = mapped_column(Float)
    wind: Mapped[float | None] = mapped_column(Float)
    humidity: Mapped[float | None] = mapped_column(Float)
    high: Mapped[float | None] = mapped_column(Float)
    low: Mapped[float | None] = mapped_column(Float)
    raw_json: Mapped[str | None] = mapped_column(Text)  # full provider payload, for debugging/reprocessing


class Setting(Base):
    """
    Simple key/value config store — recommendation weights, screen timeout,
    weather provider choice, etc. Lets those be changed from the web GUI
    instead of being hard-coded.
    """
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )
