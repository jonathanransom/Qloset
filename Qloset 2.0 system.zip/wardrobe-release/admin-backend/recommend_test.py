"""
Wardrobe System — recommendation engine test/debug CLI.

Usage:
    python recommend_test.py                  # today, using any existing recommendation
    python recommend_test.py --force           # regenerate today's recommendation
    python recommend_test.py --date 2026-12-25 # score for a specific date (e.g. to test a holiday)

Prints the full score breakdown for every eligible candidate in every
slot, sorted best-to-worst, so you can see exactly why an item was or
wasn't picked — this is the "understandable and tunable" requirement in
practice, not just in the code comments.
"""

import argparse
from datetime import date

from app.recommendation import generate_recommendation
from db.database import get_session


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default=None, help="YYYY-MM-DD; defaults to today")
    parser.add_argument("--force", action="store_true", help="Regenerate even if today's outfit already exists")
    args = parser.parse_args()

    target_date = date.fromisoformat(args.date) if args.date else date.today()

    with get_session() as session:
        outfit, debug = generate_recommendation(session, target_date=target_date, force=args.force)

        print(f"Date: {debug.get('date', target_date.isoformat())} ({target_date.strftime('%A')})")
        if debug.get("is_special_event"):
            print("  -> special event override in effect")
        print(f"Weather source: {debug.get('weather_source')}")
        if "note" in debug:
            print(f"({debug['note']})")

        for slot, scored in debug.get("slots", {}).items():
            print(f"\n--- {slot.upper()} candidates ---")
            if not scored:
                print("  (none eligible)")
                continue
            for row in scored:
                marker = ""
                print(
                    f"  {row['total']:>6.2f}  {row['name']:<25} "
                    f"rot={row['rotation']:>5.2f} weather={row['weather_fit']:>5.2f} "
                    f"sun={row['sunday_bonus']:>5.2f} pref={row['preference']:>5.2f} "
                    f"recent={row['recent_wear_penalty']:>6.2f} overuse={row['overuse_penalty']:>6.2f}"
                )

        if outfit:
            print("\n=== Recommended outfit ===")
            for oi in outfit.items:
                print(f"  {oi.slot}: {oi.clothing_item.name}")
        else:
            print(f"\nNo outfit could be generated: {debug.get('error')}")


if __name__ == "__main__":
    main()
