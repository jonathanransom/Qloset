"""
Wardrobe System — Phase 7: Physical UI kiosk app.
Runs on the Arduino UNO Q's Linux (MPU) side, inside Arduino App Lab.

This is a SEPARATE App Lab app from the admin backend (which runs as its
own uvicorn/FastAPI process, per Phase 3-6). This app's only jobs are:
  - talk to the MCU sketch for buttons + motion (via the Router Bridge,
    which only App Lab apps can use)
  - call the admin backend's HTTP API for everything else (today's
    recommendation, weather, scanning, confirming wears)
  - serve the on-screen kiosk page and drive it through a small state
    machine

Keeping recommendation/database/scanning logic OUT of this file (it all
lives in the admin backend) is what satisfies the "keep hardware-specific
code isolated" and "keep recommendation logic independent from the GUI"
coding standards — this file is pure UI/workflow glue.

Configure ADMIN_API_BASE_URL to point at wherever the admin backend is
actually running — by default, this assumes it's running on the SAME
UNO Q, as a systemd service, per the Phase 1 architecture. If you're
still running the admin backend from your Windows/Mac dev machine, point
this at that machine's IP instead so you can test the kiosk flow before
the whole thing is deployed to one board.
"""

import logging
import os
import time
from datetime import datetime
from enum import Enum

import requests
from arduino.app_utils import App, Bridge
from arduino.app_bricks.web_ui import WebUI

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("wardrobe.kiosk")

# This app runs inside its own Docker container (App Lab manages that),
# with its own network namespace — its "127.0.0.1" is NOT the UNO Q
# board's loopback, and the board's own LAN IP isn't reachable from
# inside the container's custom bridge network either. Both were tried
# and both fail with a real ConnectionError, confirmed on-device.
#
# What *is* reachable is the board's Docker default-bridge gateway,
# which App Lab already aliases in this container's /etc/hosts as
# "msgpack-rpc-router" (it uses that address for its own router-bridge
# traffic to the MCU side). The admin backend's uvicorn process listens
# on 0.0.0.0:8080 directly on the board (not containerized), so it's
# reachable at that same gateway address. Using the hostname rather than
# the raw gateway IP (typically 172.17.0.1) means this keeps working even
# if Docker's default bridge address ever changes.
#
# If you ever split the admin backend onto a different machine, override
# this with WARDROBE_ADMIN_API_URL.
ADMIN_API_BASE_URL = os.environ.get("WARDROBE_ADMIN_API_URL", "http://msgpack-rpc-router:8080")

# This is a SEPARATE address from ADMIN_API_BASE_URL above, and that's
# deliberate. ADMIN_API_BASE_URL is used by this Python process, running
# inside the kiosk's own Docker container, to reach the backend — so it
# needs a container-internal address like "msgpack-rpc-router".
#
# But the kiosk's web page (assets/index.html) is loaded by a browser
# somewhere else entirely — your PC or phone on the LAN — and that
# browser fetches clothing photos directly from the admin backend. A
# browser on a different machine has no route to "msgpack-rpc-router"
# (that name only exists inside this one container's /etc/hosts), so
# using ADMIN_API_BASE_URL for photo URLs breaks the moment you view the
# kiosk page from anywhere but inside this container. It needs the
# board's real, LAN-routable address instead. Replace the default below
# with your board's actual static LAN IP (or set WARDROBE_ADMIN_PUBLIC_URL
# in this app's environment instead of editing the code).
ADMIN_PUBLIC_BASE_URL = os.environ.get("WARDROBE_ADMIN_PUBLIC_URL", "http://192.168.1.50:8080")

SCREEN_TIMEOUT_SECONDS = 60
API_TIMEOUT_SECONDS = 8

# POST /api/scan is special: the backend deliberately HOLDS the request
# open while it watches the camera for a QR code, for up to its own
# WARDROBE_SCAN_TIMEOUT_SECONDS (10s by default — see app/qr_scanner.py
# on the backend). That means a normal, successful scan attempt can take
# nearly that long to respond. If this kiosk's own HTTP timeout is
# shorter than the backend's scan window, every real scan attempt looks
# like a failed connection ("couldn't reach the camera service") even
# though the backend is working correctly — it just hasn't answered yet.
# This must stay comfortably LONGER than the backend's scan timeout.
# Paired with WARDROBE_SCAN_TIMEOUT_SECONDS=15 in the backend's env file —
# keep these two moving together (see the wardrobe.env.example comment).
SCAN_API_TIMEOUT_SECONDS = 25


class Screen(str, Enum):
    loading = "loading"
    outfit = "outfit"          # normal "today's outfit" view with WEAR THIS / CHANGE
    scanning = "scanning"      # "scan the item you're wearing" — camera active
    scan_result = "scan_result"  # briefly shows what was scanned, then back to scanning or done
    done = "done"              # "Got it! Have a great day."
    error = "error"


state = {
    "screen": Screen.loading,
    "screen_awake": True,
    "last_activity_at": time.monotonic(),
    "mcu_alive": False,
    "recommendation": None,   # cached GET /api/recommendation/today response
    "weather": None,          # cached GET /api/weather/current response
    "scanned_items": [],       # items confirmed so far in the current CHANGE workflow
    "scan_attempt": 0,         # bumped each time do_scan() starts a fresh camera scan —
                                # lets the kiosk page tell "still on the scanning screen"
                                # apart from "a new scan just started", so it knows when to
                                # reconnect the live preview stream rather than reuse a
                                # dead one from the previous scan attempt
    "last_scan_status": None,
    "message": None,
    "error_message": None,
}


def _extract_error_detail(resp: requests.Response) -> str:
    """
    FastAPI error responses carry the real reason in JSON `detail`, which
    can be a plain string or (as recommendation.py's 422 does) a dict like
    {"message": "...", "debug": {...}}. Pull out something readable
    rather than showing the raw response or swallowing it.
    """
    try:
        body = resp.json()
    except ValueError:
        return resp.text[:200] if resp.text else f"HTTP {resp.status_code}"
    detail = body.get("detail", body)
    if isinstance(detail, dict):
        return str(detail.get("message", detail))
    return str(detail)


def _api_get(path: str) -> tuple[dict | None, str | None]:
    """
    Returns (data, error). error is None on success. On failure, error is
    a human-readable reason — either the connection problem, or, for a
    request that reached the server but got an error response, whatever
    that response actually said (e.g. "No valid outfit could be generated
    for today"). Collapsing both cases into one generic message was the
    bug that made a real backend error look identical to a network
    problem — keep them distinct so whoever's debugging isn't sent
    chasing the wrong thing.
    """
    try:
        resp = requests.get(f"{ADMIN_API_BASE_URL}{path}", timeout=API_TIMEOUT_SECONDS)
    except requests.RequestException as exc:
        log.warning("GET %s: connection failed: %s", path, exc)
        return None, f"Can't connect to {ADMIN_API_BASE_URL} ({exc.__class__.__name__})"

    if resp.status_code >= 400:
        detail = _extract_error_detail(resp)
        log.warning("GET %s: server returned %s: %s", path, resp.status_code, detail)
        return None, detail

    return resp.json(), None


def _api_post(path: str, json: dict | None = None, timeout: float = API_TIMEOUT_SECONDS) -> tuple[dict | None, str | None]:
    try:
        resp = requests.post(f"{ADMIN_API_BASE_URL}{path}", json=json, timeout=timeout)
    except requests.RequestException as exc:
        log.warning("POST %s: connection failed: %s", path, exc)
        return None, f"Can't connect to {ADMIN_API_BASE_URL} ({exc.__class__.__name__})"

    if resp.status_code >= 400:
        detail = _extract_error_detail(resp)
        log.warning("POST %s: server returned %s: %s", path, resp.status_code, detail)
        return None, detail

    return resp.json(), None


def refresh_recommendation():
    """
    Called on wake and after a wear is confirmed. If the admin backend is
    unreachable, keeps whatever was last successfully loaded rather than
    blanking the screen — Section 23's "don't completely stop working"
    rule applies here too: a stale outfit shown is better than no outfit
    shown.
    """
    rec, rec_error = _api_get("/api/recommendation/today")
    if rec is not None:
        state["recommendation"] = rec

    weather, weather_error = _api_get("/api/weather/current")
    if weather is not None:
        state["weather"] = weather

    if state["recommendation"] is None:
        state["screen"] = Screen.error
        state["error_message"] = rec_error or "Couldn't reach the wardrobe server. Is it running?"
    elif state["screen"] in (Screen.loading, Screen.error):
        state["screen"] = Screen.outfit
        state["error_message"] = None


def touch_activity():
    state["last_activity_at"] = time.monotonic()
    state["screen_awake"] = True


def go_to_outfit_screen():
    state["screen"] = Screen.outfit
    state["scanned_items"] = []
    state["last_scan_status"] = None


# --- Button handlers -----------------------------------------------------

def on_button_pressed(name: str):
    log.info("Button pressed: %s (current screen: %s)", name, state["screen"])
    touch_activity()

    if name == "wear_this" and state["screen"] == Screen.outfit:
        result, error = _api_post("/api/recommendation/today/confirm")
        if result is None:
            state["message"] = error or "Couldn't save that — check the connection and try again."
        else:
            state["message"] = "Nice! Enjoy your day."
            state["screen"] = Screen.done

    elif name == "change" and state["screen"] == Screen.outfit:
        state["screen"] = Screen.scanning
        state["scanned_items"] = []
        state["last_scan_status"] = None
        do_scan()  # triggers the first scan attempt immediately

    elif name == "change" and state["screen"] == Screen.scanning:
        do_scan()  # scan the next item

    elif name == "done" and state["screen"] == Screen.scanning:
        if state["scanned_items"]:
            state["screen"] = Screen.done
            state["message"] = "Got it — outfit recorded. Have a great day!"
        else:
            state["last_scan_status"] = "Scan at least one item before pressing Done."

    elif name in ("wear_this", "change", "done") and state["screen"] in (Screen.done, Screen.error):
        # Any button from a resting screen returns to the main outfit view.
        refresh_recommendation()
        go_to_outfit_screen()


def on_motion_detected(_value: bool = True):
    touch_activity()


def do_scan():
    """
    Runs one scan attempt against the admin backend's camera, then
    immediately confirms the result if it matched a known item — this
    collapses Section 11's "scan -> identify -> confirm" into a single
    button press per item, since re-scanning is just another press of
    CHANGE if something goes wrong.
    """
    state["scan_attempt"] += 1
    state["last_scan_status"] = "Scanning..."
    _set_scan_led(True)
    try:
        result, error = _api_post("/api/scan", timeout=SCAN_API_TIMEOUT_SECONDS)
        if result is None:
            state["last_scan_status"] = error or "Couldn't reach the camera service."
            return

        status = result.get("status")
        if status == "camera_unavailable":
            state["last_scan_status"] = "Camera not available right now."
        elif status == "timeout":
            state["last_scan_status"] = "No QR code seen — try again, closer to the camera."
        elif status == "unknown_code":
            state["last_scan_status"] = f"That QR code ({result.get('qr_code')}) isn't in the system yet."
        elif status == "detected":
            item = result["item"]
            confirm, confirm_error = _api_post("/api/scan/confirm", json={"clothing_item_id": item["id"]})
            if confirm is None:
                state["last_scan_status"] = confirm_error or f"Saw {item['name']}, but couldn't record it — try again."
            else:
                state["scanned_items"].append(item)
                state["last_scan_status"] = f"Recorded: {item['name']}"
    finally:
        # Always turn the LED back off, however the scan attempt ended —
        # a successful detection, a timeout, camera_unavailable, or even
        # a connection failure to the backend (the `return` above).
        _set_scan_led(False)


def _set_scan_led(on: bool):
    """
    Tells the MCU sketch (see sketch.ino's set_scan_led()) to turn the
    scan-indicator LED on or off. Best-effort: if the MCU is slow to
    respond or the call fails outright, that's not worth failing the
    actual scan over — log it and keep going.
    """
    try:
        Bridge.call("set_scan_led", on, timeout=2)
    except Exception as exc:
        log.warning("set_scan_led(%s) failed: %s", on, exc)


Bridge.provide("button_pressed", on_button_pressed)
Bridge.provide("motion_detected", on_motion_detected)

ui = WebUI()


def get_status(_request=None):
    idle_seconds = time.monotonic() - state["last_activity_at"]
    state["screen_awake"] = idle_seconds < SCREEN_TIMEOUT_SECONDS
    return {
        "screen": state["screen"],
        "screen_awake": state["screen_awake"],
        "mcu_alive": state["mcu_alive"],
        "admin_api_base_url": ADMIN_PUBLIC_BASE_URL,
        "scan_attempt": state["scan_attempt"],
        "recommendation": state["recommendation"],
        "weather": state["weather"],
        "scanned_items": state["scanned_items"],
        "last_scan_status": state["last_scan_status"],
        "message": state["message"],
        "error_message": state["error_message"],
        "now": datetime.now().strftime("%A, %B %-d"),
    }


ui.expose_api("GET", "/api/status", get_status)


def loop():
    try:
        state["mcu_alive"] = bool(Bridge.call("ping", timeout=2))
    except Exception as exc:
        state["mcu_alive"] = False
        log.warning("MCU ping failed: %s", exc)

    # Refresh the recommendation periodically while on the outfit screen,
    # so an overnight weather change or an admin edit shows up without
    # needing a manual refresh — but not while mid-scan, where a
    # refresh would be a distracting screen change.
    if state["screen"] == Screen.outfit:
        refresh_recommendation()
    elif state["screen"] == Screen.loading:
        refresh_recommendation()

    time.sleep(5)


App.run(user_loop=loop)
