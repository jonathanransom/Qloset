/*
 * Wardrobe System — Phase 7: Physical UI hardware
 * Runs on the Arduino UNO Q's STM32U585 MCU (Zephyr side), via Arduino App Lab.
 *
 * Same hardware role as Phase 2, with one addition: a third button
 * ("done") for the multi-item scan workflow in Section 11 — after
 * scanning each actual item worn, pressing DONE tells Python the scan
 * sequence is finished.
 *
 * Responsibilities:
 *   - Read three physical buttons (WEAR_THIS, CHANGE, DONE), debounced
 *   - Read a PIR motion sensor, edge-triggered
 *   - Push button/motion events to the Linux (Python) side over the Router Bridge
 *   - Expose a "ping" function so the Python side can confirm the MCU is alive
 *
 * Wiring (ADJUST these pin numbers to match how you actually wire things —
 * check the UNO Q pinout diagram for the exact digital pin labels):
 *   WEAR_THIS button -> digital pin D2, other leg to GND (uses internal pull-up)
 *   CHANGE button     -> digital pin D3, other leg to GND (uses internal pull-up)
 *   DONE button       -> digital pin D5, other leg to GND (uses internal pull-up)
 *   PIR motion OUT    -> digital pin D4 (PIR modules drive HIGH/LOW themselves,
 *                        no pull-up needed — confirm against your specific module's datasheet)
 *   Scan LED (+)      -> digital pin D6, through a current-limiting resistor,
 *                        other leg to GND. Lit for the duration of a camera
 *                        scan attempt, so it's obvious when the camera is
 *                        watching for a QR code.
 */

#include <Arduino_RouterBridge.h>

const uint8_t PIN_BUTTON_WEAR_THIS = 2;
const uint8_t PIN_BUTTON_CHANGE    = 3;
const uint8_t PIN_MOTION           = 4;
const uint8_t PIN_BUTTON_DONE      = 5;
const uint8_t PIN_LED_SCAN         = 6;

const unsigned long DEBOUNCE_MS = 40;

struct ButtonState {
  uint8_t pin;
  const char* name;
  int lastReading;
  int stableState;
  unsigned long lastChangeMs;
};

ButtonState buttons[] = {
  { PIN_BUTTON_WEAR_THIS, "wear_this", HIGH, HIGH, 0 },
  { PIN_BUTTON_CHANGE,    "change",    HIGH, HIGH, 0 },
  { PIN_BUTTON_DONE,      "done",      HIGH, HIGH, 0 },
};
const uint8_t NUM_BUTTONS = sizeof(buttons) / sizeof(buttons[0]);

int motionState = LOW;
unsigned long lastMotionChangeMs = 0;

// Called from Python via Bridge.call("ping") to confirm the MCU is alive and responsive.
bool ping() {
  return true;
}

// Called from Python (main.py's do_scan()) via Bridge.call("set_scan_led", on)
// to turn the scan-indicator LED on for the duration of a camera scan
// attempt, and off again once it ends (found, timed out, or camera
// unavailable). Returns true so the Python side has something to
// confirm the call actually reached the MCU, same as ping() above.
bool set_scan_led(bool on) {
  digitalWrite(PIN_LED_SCAN, on ? HIGH : LOW);
  return true;
}

void setup() {
  for (uint8_t i = 0; i < NUM_BUTTONS; i++) {
    pinMode(buttons[i].pin, INPUT_PULLUP);
  }
  pinMode(PIN_MOTION, INPUT);
  pinMode(PIN_LED_SCAN, OUTPUT);
  digitalWrite(PIN_LED_SCAN, LOW);

  Bridge.begin();
  Bridge.provide("ping", ping);
  Bridge.provide("set_scan_led", set_scan_led);
}

void loop() {
  unsigned long now = millis();

  // --- Buttons: active LOW (internal pull-up, other leg to GND) ---
  for (uint8_t i = 0; i < NUM_BUTTONS; i++) {
    int reading = digitalRead(buttons[i].pin);

    if (reading != buttons[i].lastReading) {
      buttons[i].lastChangeMs = now;
      buttons[i].lastReading = reading;
    }

    if ((now - buttons[i].lastChangeMs) > DEBOUNCE_MS && reading != buttons[i].stableState) {
      buttons[i].stableState = reading;
      if (reading == LOW) { // press, not release
        Bridge.notify("button_pressed", buttons[i].name);
      }
    }
  }

  // --- Motion sensor: active HIGH ---
  int motionReading = digitalRead(PIN_MOTION);
  if (motionReading != motionState && (now - lastMotionChangeMs) > DEBOUNCE_MS) {
    motionState = motionReading;
    lastMotionChangeMs = now;
    if (motionState == HIGH) {
      Bridge.notify("motion_detected", true);
    }
  }

  delay(10);
}
